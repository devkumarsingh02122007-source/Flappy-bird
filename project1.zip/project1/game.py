import pygame
import sys
import os
import json
import random
import math

from constants import (
    SCREEN_WIDTH, SCREEN_HEIGHT, GROUND_HEIGHT, FPS,
    GRAVITY, FLAP_STRENGTH, MAX_FALL_SPEED, ROTATION_SPEED,
    PIPE_SPEED, PIPE_GAP, PIPE_WIDTH, PIPE_MIN_HEIGHT,
    PIPE_SPAWN_INTERVAL, THEMES, SKIN_NAMES, SKIN_COLORS,
    MEDAL_THRESHOLDS
)
from sound_generator import generate_all_sounds, SOUNDS_DIR
import sprites
from particles import ParticleManager

class Bird:
    def __init__(self, x, y, skin="classic"):
        self.x = x
        self.y = y
        self.skin = skin
        self.velocity = 0
        self.rotation = 0
        self.frame_index = 0
        self.animation_timer = 0
        self.load_skin(skin)
        self.alive = True

    def load_skin(self, skin):
        self.skin = skin
        self.frames = sprites.create_bird_surfaces(skin)
        self.rect = pygame.Rect(self.x - 15, self.y - 12, 30, 24)

    def flap(self):
        self.velocity = FLAP_STRENGTH
        self.animation_timer = 0

    def update(self, is_playing=True):
        if is_playing:
            # Gravity physics
            self.velocity += GRAVITY
            if self.velocity > MAX_FALL_SPEED:
                self.velocity = MAX_FALL_SPEED
            self.y += self.velocity

            # Dynamic rotation:
            # When rising, tilt up (-25°). When falling, smoothly nose-dive (+75°)
            if self.velocity < 0:
                target_rotation = max(-25.0, self.velocity * 4.0)
            else:
                target_rotation = min(75.0, (self.velocity - 2.0) * 12.0)
                
            self.rotation += (target_rotation - self.rotation) * 0.18
            
            # Wing animation (faster flap when rising)
            flap_speed = 4 if self.velocity < 0 else 7
            self.animation_timer += 1
            if self.animation_timer >= flap_speed:
                self.animation_timer = 0
                self.frame_index = (self.frame_index + 1) % len(self.frames)
        else:
            # Hover / bob animation for menu
            self.frame_index = 1
            self.rotation = 0

        # Update collision box (slightly inset for fairness)
        self.rect.center = (int(self.x), int(self.y))

    def draw(self, surface):
        current_frame = self.frames[self.frame_index]
        # Invert rotation for pygame's coordinate system
        rotated_surface = pygame.transform.rotate(current_frame, -self.rotation)
        rotated_rect = rotated_surface.get_rect(center=(int(self.x), int(self.y)))
        surface.blit(rotated_surface, rotated_rect)

class PipePair:
    def __init__(self, x, top_surf, bot_surf):
        self.x = x
        self.top_surf = top_surf
        self.bot_surf = bot_surf
        self.passed = False
        
        # Calculate random gap position
        ground_top = SCREEN_HEIGHT - GROUND_HEIGHT
        min_center = PIPE_MIN_HEIGHT + PIPE_GAP // 2
        max_center = ground_top - PIPE_MIN_HEIGHT - PIPE_GAP // 2
        
        gap_center = random.randint(min_center, max_center)
        self.top_pipe_bottom = gap_center - PIPE_GAP // 2
        self.bot_pipe_top = gap_center + PIPE_GAP // 2
        
        self.width = top_surf.get_width()
        self.surf_height = top_surf.get_height()

    def update(self):
        self.x -= PIPE_SPEED

    def collides_with(self, bird_rect):
        # Top pipe rect
        top_rect = pygame.Rect(
            self.x, self.top_pipe_bottom - self.surf_height,
            self.width, self.surf_height
        )
        # Bottom pipe rect
        bot_rect = pygame.Rect(
            self.x, self.bot_pipe_top,
            self.width, self.surf_height
        )
        
        # Slight hitbox tolerance (3px inset) for smooth arcade fairness
        top_hitbox = top_rect.inflate(-6, -4)
        bot_hitbox = bot_rect.inflate(-6, -4)
        
        return bird_rect.colliderect(top_hitbox) or bird_rect.colliderect(bot_hitbox)

    def draw(self, surface):
        # Draw top pipe (anchored at its bottom)
        surface.blit(self.top_surf, (self.x, self.top_pipe_bottom - self.surf_height))
        # Draw bottom pipe (anchored at its top)
        surface.blit(self.bot_surf, (self.x, self.bot_pipe_top))

class FlappyBirdGame:
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        pygame.font.init()

        # Display Setup
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Flappy Bird Arcade Clone")
        
        self.clock = pygame.time.Clock()
        self.running = True

        # Ensure sound files exist
        generate_all_sounds()

        # Assets & Sprites
        self.theme_index = 0
        self.skin_index = 0
        self.backgrounds = sprites.create_backgrounds()
        self.top_pipe_surf, self.bot_pipe_surf = sprites.create_pipe_surfaces()
        self.ground_surf = sprites.create_ground_surface()
        self.ground_x = 0

        # Set Window Icon
        icon_frame = sprites.create_bird_surfaces("classic")[0]
        pygame.display.set_icon(icon_frame)

        # Audio
        self.muted = False
        self.sounds = self.load_sounds()

        # Fonts
        self.font_large = pygame.font.SysFont("impact", 44)
        self.font_mid = pygame.font.SysFont("impact", 28)
        self.font_small = pygame.font.SysFont("segoeui", 16, bold=True)
        self.font_badge = pygame.font.SysFont("impact", 18)

        # High Score file
        self.save_file = os.path.join(os.path.dirname(__file__), "highscore.json")
        self.high_score = self.load_high_score()

        # Particle Manager
        self.particles = ParticleManager()

        # Game States: 'MENU', 'PLAYING', 'PAUSED', 'GAME_OVER'
        self.state = "MENU"
        self.score = 0
        self.pipes = []
        self.last_pipe_time = 0
        self.bird = Bird(SCREEN_WIDTH // 3, SCREEN_HEIGHT // 2, SKIN_NAMES[self.skin_index])
        
        # Polish & FX
        self.screen_shake = 0
        self.flash_alpha = 0
        self.score_scale_timer = 0
        self.is_new_high_score = False
        self.menu_bob_timer = 0
        self.game_over_panel_y = SCREEN_HEIGHT

    def load_sounds(self):
        snds = {}
        for name in ["flap", "point", "hit", "die", "swoosh", "celebrate"]:
            path = os.path.join(SOUNDS_DIR, f"{name}.wav")
            if os.path.exists(path):
                snds[name] = pygame.mixer.Sound(path)
                snds[name].set_volume(0.65)
        return snds

    def play_sound(self, name):
        if not self.muted and name in self.sounds:
            self.sounds[name].play()

    def toggle_mute(self):
        self.muted = not self.muted

    def next_skin(self):
        self.skin_index = (self.skin_index + 1) % len(SKIN_NAMES)
        skin = SKIN_NAMES[self.skin_index]
        self.bird.load_skin(skin)
        self.play_sound("swoosh")

    def next_theme(self):
        self.theme_index = (self.theme_index + 1) % len(THEMES)
        self.play_sound("swoosh")

    def load_high_score(self):
        if os.path.exists(self.save_file):
            try:
                with open(self.save_file, "r") as f:
                    data = json.load(f)
                    return data.get("high_score", 0)
            except Exception:
                return 0
        return 0

    def save_high_score(self):
        try:
            with open(self.save_file, "w") as f:
                json.dump({"high_score": self.high_score}, f)
        except Exception:
            pass

    def reset_game(self):
        self.score = 0
        self.pipes.clear()
        self.last_pipe_time = pygame.time.get_ticks()
        self.bird = Bird(SCREEN_WIDTH // 3, SCREEN_HEIGHT // 2 - 20, SKIN_NAMES[self.skin_index])
        self.state = "PLAYING"
        self.screen_shake = 0
        self.flash_alpha = 0
        self.is_new_high_score = False
        self.game_over_panel_y = SCREEN_HEIGHT
        self.particles.clear()
        self.bird.flap()
        self.play_sound("flap")

    def handle_flap(self):
        if self.state == "MENU":
            self.reset_game()
        elif self.state == "PLAYING":
            self.bird.flap()
            self.play_sound("flap")
            self.particles.spawn_flap_puff(self.bird.x, self.bird.y)
        elif self.state == "GAME_OVER":
            # Small cooldown before restart is allowed
            if self.game_over_panel_y <= SCREEN_HEIGHT // 2 + 10:
                self.reset_game()

    def trigger_game_over(self):
        self.state = "GAME_OVER"
        self.play_sound("hit")
        self.play_sound("die")
        self.screen_shake = 16
        self.flash_alpha = 200
        
        skin_c = SKIN_COLORS[self.bird.skin]["body"]
        self.particles.spawn_hit_feathers(self.bird.x, self.bird.y, skin_c)

        if self.score > self.high_score:
            self.high_score = self.score
            self.is_new_high_score = True
            self.save_high_score()
            self.play_sound("celebrate")
            self.particles.spawn_confetti(SCREEN_WIDTH, 45)

    def update(self):
        now = pygame.time.get_ticks()
        
        # Screen Shake decay
        if self.screen_shake > 0:
            self.screen_shake -= 1

        # Flash effect decay
        if self.flash_alpha > 0:
            self.flash_alpha = max(0, self.flash_alpha - 15)

        # Particles
        self.particles.update()

        # Ground scrolling
        if self.state in ["MENU", "PLAYING"]:
            self.ground_x = (self.ground_x - PIPE_SPEED) % 24

        if self.state == "MENU":
            self.menu_bob_timer += 0.08
            self.bird.y = (SCREEN_HEIGHT // 2 - 40) + math.sin(self.menu_bob_timer) * 9
            self.bird.update(is_playing=False)

        elif self.state == "PLAYING":
            self.bird.update(is_playing=True)

            # Spawn pipes
            if now - self.last_pipe_time > PIPE_SPAWN_INTERVAL:
                self.pipes.append(PipePair(SCREEN_WIDTH + 15, self.top_pipe_surf, self.bot_pipe_surf))
                self.last_pipe_time = now

            # Update pipes
            ground_y = SCREEN_HEIGHT - GROUND_HEIGHT
            for pipe in self.pipes:
                pipe.update()

                # Score point when passing pipe center
                if not pipe.passed and pipe.x + pipe.width < self.bird.x:
                    pipe.passed = True
                    self.score += 1
                    self.score_scale_timer = 8
                    self.play_sound("point")
                    self.particles.spawn_score_sparkles(self.bird.x, self.bird.y)

                # Collision check
                if pipe.collides_with(self.bird.rect):
                    self.trigger_game_over()
                    return

            # Remove offscreen pipes
            self.pipes = [p for p in self.pipes if p.x + p.width > -20]

            # Ceiling and Ground collision
            if self.bird.y - 12 <= 0:
                self.bird.y = 12
                self.bird.velocity = 0

            if self.bird.y + 12 >= ground_y:
                self.bird.y = ground_y - 12
                self.trigger_game_over()

        elif self.state == "GAME_OVER":
            # Let bird fall to the ground
            ground_y = SCREEN_HEIGHT - GROUND_HEIGHT
            if self.bird.y + 12 < ground_y:
                self.bird.velocity += GRAVITY
                self.bird.y += self.bird.velocity
                self.bird.rotation = min(90, self.bird.rotation + 4)
            else:
                self.bird.y = ground_y - 12

            # Slide-in animation for game over panel
            target_y = SCREEN_HEIGHT // 2 - 60
            if self.game_over_panel_y > target_y:
                self.game_over_panel_y -= 14
                if self.game_over_panel_y < target_y:
                    self.game_over_panel_y = target_y

    def render_text_with_shadow(self, text, font, color, shadow_color, pos, align="center", shadow_offset=2):
        txt_surf = font.render(text, True, color)
        sh_surf = font.render(text, True, shadow_color)
        
        w, h = txt_surf.get_size()
        if align == "center":
            x = pos[0] - w // 2
            y = pos[1] - h // 2
        elif align == "right":
            x = pos[0] - w
            y = pos[1]
        else:
            x, y = pos[0], pos[1]

        # Draw shadow then main text
        self.screen.blit(sh_surf, (x + shadow_offset, y + shadow_offset))
        self.screen.blit(txt_surf, (x, y))

    def draw_hud(self):
        # Draw Real-time score during PLAYING
        if self.state == "PLAYING":
            scale = 1.2 if self.score_scale_timer > 0 else 1.0
            if self.score_scale_timer > 0:
                self.score_scale_timer -= 1
            
            score_str = str(self.score)
            self.render_text_with_shadow(
                score_str, self.font_large,
                (255, 255, 255), (40, 40, 50),
                (SCREEN_WIDTH // 2, 70), align="center", shadow_offset=3
            )

        # Mute indicator top right
        mute_text = "MUTED" if self.muted else "SOUND ON"
        c = (230, 80, 80) if self.muted else (200, 240, 200)
        self.render_text_with_shadow(
            f"[M] {mute_text}", self.font_small,
            c, (20, 20, 20), (SCREEN_WIDTH - 12, 12), align="right", shadow_offset=1
        )

    def draw_menu(self):
        # Flappy Bird Title Banner with 3D Pop
        self.render_text_with_shadow(
            "FLAPPY BIRD", self.font_large,
            (255, 220, 40), (180, 80, 10),
            (SCREEN_WIDTH // 2, 120), align="center", shadow_offset=4
        )

        # Tap / Flap prompt with pulsing glow
        pulse = abs(math.sin(pygame.time.get_ticks() * 0.005))
        prompt_color = (255, int(220 + 35 * pulse), int(100 + 155 * pulse))
        self.render_text_with_shadow(
            "PRESS SPACE TO FLAP", self.font_mid,
            prompt_color, (40, 40, 50),
            (SCREEN_WIDTH // 2, 330), align="center", shadow_offset=2
        )

        # Current Skin & Theme selectors
        skin_name = SKIN_COLORS[SKIN_NAMES[self.skin_index]]["name"]
        theme_name = THEMES[self.theme_index].upper()

        box_w, box_h = 320, 70
        bx = (SCREEN_WIDTH - box_w) // 2
        by = 370
        
        # Translucent glass panel
        panel = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        panel.fill((0, 0, 0, 90))
        pygame.draw.rect(panel, (255, 255, 255, 120), (0, 0, box_w, box_h), 2, border_radius=10)
        self.screen.blit(panel, (bx, by))

        self.render_text_with_shadow(
            f"[S] Skin: {skin_name}", self.font_small,
            (255, 255, 255), (0, 0, 0),
            (SCREEN_WIDTH // 2, by + 22), align="center"
        )
        self.render_text_with_shadow(
            f"[T] Theme: {theme_name}  |  High Score: {self.high_score}", self.font_small,
            (255, 235, 150), (0, 0, 0),
            (SCREEN_WIDTH // 2, by + 48), align="center"
        )

    def draw_game_over(self):
        py = self.game_over_panel_y
        
        # "GAME OVER" Title
        self.render_text_with_shadow(
            "GAME OVER", self.font_large,
            (245, 70, 60), (90, 20, 20),
            (SCREEN_WIDTH // 2, py - 45), align="center", shadow_offset=4
        )

        # Score Card Box
        box_w, box_h = 310, 155
        bx = (SCREEN_WIDTH - box_w) // 2
        by = py
        
        # Card Background
        card_surf = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        card_surf.fill((235, 225, 185, 245))
        pygame.draw.rect(card_surf, (110, 85, 55), (0, 0, box_w, box_h), 3, border_radius=12)
        pygame.draw.rect(card_surf, (255, 250, 230), (3, 3, box_w - 6, box_h - 6), 2, border_radius=10)
        self.screen.blit(card_surf, (bx, by))

        # Medal section
        self.render_text_with_shadow(
            "MEDAL", self.font_badge,
            (110, 85, 55), (255, 255, 255),
            (bx + 60, by + 28), align="center", shadow_offset=1
        )
        
        # Award Medal based on score
        awarded_medal = None
        for m_name, thresh in MEDAL_THRESHOLDS.items():
            if self.score >= thresh:
                awarded_medal = m_name
                break

        if awarded_medal:
            med_surf = sprites.create_medal(awarded_medal)
            self.screen.blit(med_surf, (bx + 38, by + 48))
        else:
            # Empty medal ring
            pygame.draw.circle(self.screen, (175, 160, 135), (bx + 60, by + 70), 20, 2)

        # Score & High Score texts
        self.render_text_with_shadow(
            "SCORE", self.font_badge,
            (110, 85, 55), (255, 255, 255),
            (bx + 200, by + 28), align="center", shadow_offset=1
        )
        self.render_text_with_shadow(
            str(self.score), self.font_mid,
            (40, 40, 50), (255, 255, 255),
            (bx + 265, by + 30), align="right", shadow_offset=1
        )

        self.render_text_with_shadow(
            "BEST", self.font_badge,
            (110, 85, 55), (255, 255, 255),
            (bx + 200, by + 80), align="center", shadow_offset=1
        )
        self.render_text_with_shadow(
            str(self.high_score), self.font_mid,
            (40, 40, 50), (255, 255, 255),
            (bx + 265, by + 82), align="right", shadow_offset=1
        )

        # NEW High score badge
        if self.is_new_high_score:
            badge_surf = pygame.Surface((44, 18))
            badge_surf.fill((230, 60, 40))
            self.screen.blit(badge_surf, (bx + 145, by + 74))
            self.render_text_with_shadow(
                "NEW", self.font_small,
                (255, 255, 255), (100, 20, 20),
                (bx + 167, by + 83), align="center", shadow_offset=1
            )

        # Restart instruction prompt
        pulse = abs(math.sin(pygame.time.get_ticks() * 0.007))
        c_btn = (255, int(220 + 35 * pulse), int(100 + 155 * pulse))
        self.render_text_with_shadow(
            "PRESS SPACE TO RESTART", self.font_mid,
            c_btn, (30, 30, 40),
            (SCREEN_WIDTH // 2, by + box_h + 35), align="center", shadow_offset=2
        )

    def draw_paused(self):
        # Dark dimming layer
        dim = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 140))
        self.screen.blit(dim, (0, 0))

        self.render_text_with_shadow(
            "GAME PAUSED", self.font_large,
            (255, 255, 255), (30, 30, 40),
            (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 30), align="center", shadow_offset=3
        )
        self.render_text_with_shadow(
            "Press P to Resume", self.font_mid,
            (240, 220, 120), (30, 30, 40),
            (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 25), align="center", shadow_offset=2
        )

    def draw(self):
        # Handle Screen Shake offset
        ox = random.randint(-self.screen_shake, self.screen_shake) if self.screen_shake > 0 else 0
        oy = random.randint(-self.screen_shake, self.screen_shake) if self.screen_shake > 0 else 0

        # 1. Background Theme
        current_theme_key = THEMES[self.theme_index]
        bg_surface = self.backgrounds[current_theme_key]
        self.screen.blit(bg_surface, (ox, oy))

        # 2. Pipes
        for pipe in self.pipes:
            pipe.draw(self.screen)

        # 3. Ground (seamless loop)
        ground_y = SCREEN_HEIGHT - GROUND_HEIGHT
        self.screen.blit(self.ground_surf, (self.ground_x + ox, ground_y + oy))

        # 4. Particles (feathers, sparks, puffs)
        self.particles.draw(self.screen)

        # 5. Bird
        self.bird.draw(self.screen)

        # 6. UI / State screens
        if self.state == "MENU":
            self.draw_menu()
        elif self.state == "GAME_OVER":
            self.draw_game_over()
        elif self.state == "PAUSED":
            self.draw_paused()

        # 7. HUD
        self.draw_hud()

        # 8. Flash effect on impact
        if self.flash_alpha > 0:
            flash_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            flash_surf.fill((255, 255, 255))
            flash_surf.set_alpha(self.flash_alpha)
            self.screen.blit(flash_surf, (0, 0))

        pygame.display.flip()

    def run(self):
        while self.running:
            self.clock.tick(FPS)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

                elif event.type == pygame.KEYDOWN:
                    if event.key in [pygame.K_SPACE, pygame.K_UP, pygame.K_w]:
                        self.handle_flap()
                    elif event.key == pygame.K_p:
                        if self.state == "PLAYING":
                            self.state = "PAUSED"
                        elif self.state == "PAUSED":
                            self.state = "PLAYING"
                    elif event.key == pygame.K_m:
                        self.toggle_mute()
                    elif event.key == pygame.K_s:
                        if self.state in ["MENU", "GAME_OVER"]:
                            self.next_skin()
                    elif event.key == pygame.K_t:
                        if self.state in ["MENU", "GAME_OVER"]:
                            self.next_theme()
                    elif event.key == pygame.K_r:
                        if self.state == "GAME_OVER":
                            self.reset_game()
                    elif event.key == pygame.K_ESCAPE:
                        if self.state == "PLAYING":
                            self.state = "PAUSED"
                        elif self.state == "PAUSED":
                            self.state = "PLAYING"
                        else:
                            self.running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # Left Click
                        self.handle_flap()

            self.update()
            self.draw()

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = FlappyBirdGame()
    game.run()
