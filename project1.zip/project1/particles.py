import pygame
import random
import math

class Particle:
    def __init__(self, x, y, vx, vy, color, size, lifespan, shape="circle"):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.color = color
        self.size = size
        self.initial_size = size
        self.lifespan = lifespan
        self.age = 0
        self.shape = shape
        self.rotation = random.uniform(0, 360)
        self.rot_speed = random.uniform(-10, 10)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.age += 1
        self.rotation += self.rot_speed
        
        # Air friction and gravity
        if self.shape == "feather":
            self.vy += 0.08  # Gentle gravity
            self.vx *= 0.96
        elif self.shape == "confetti":
            self.vy += 0.12
            self.vx += math.sin(self.age * 0.1) * 0.2
        elif self.shape == "puff":
            self.vx *= 0.92
            self.vy *= 0.92
        elif self.shape == "sparkle":
            self.vx *= 0.94
            self.vy *= 0.94

    @property
    def alive(self):
        return self.age < self.lifespan

    def draw(self, surface):
        if not self.alive:
            return
            
        progress = self.age / self.lifespan
        alpha = int(255 * (1.0 - progress))
        current_size = max(1, int(self.initial_size * (1.0 - progress * 0.5)))
        
        if self.shape == "circle" or self.shape == "sparkle":
            s = pygame.Surface((current_size * 2, current_size * 2), pygame.SRCALPHA)
            c = (*self.color[:3], alpha)
            pygame.draw.circle(s, c, (current_size, current_size), current_size)
            surface.blit(s, (int(self.x - current_size), int(self.y - current_size)))
            
        elif self.shape == "puff":
            s = pygame.Surface((current_size * 2, current_size * 2), pygame.SRCALPHA)
            c = (*self.color[:3], int(alpha * 0.7))
            pygame.draw.circle(s, c, (current_size, current_size), current_size, 2)
            surface.blit(s, (int(self.x - current_size), int(self.y - current_size)))
            
        elif self.shape == "feather":
            fw = max(3, current_size * 2)
            fh = max(2, current_size)
            s = pygame.Surface((fw, fh), pygame.SRCALPHA)
            c = (*self.color[:3], alpha)
            pygame.draw.ellipse(s, c, (0, 0, fw, fh))
            rot_s = pygame.transform.rotate(s, self.rotation)
            rect = rot_s.get_rect(center=(int(self.x), int(self.y)))
            surface.blit(rot_s, rect)
            
        elif self.shape == "confetti":
            w = current_size * 2
            h = current_size
            s = pygame.Surface((w, h), pygame.SRCALPHA)
            c = (*self.color[:3], alpha)
            s.fill(c)
            rot_s = pygame.transform.rotate(s, self.rotation)
            rect = rot_s.get_rect(center=(int(self.x), int(self.y)))
            surface.blit(rot_s, rect)

class ParticleManager:
    def __init__(self):
        self.particles = []

    def spawn_flap_puff(self, x, y):
        # Ring puff behind bird
        self.particles.append(
            Particle(x - 12, y + 6, -1.0, 0.5, (255, 255, 255), size=9, lifespan=14, shape="puff")
        )
        # Small feather
        self.particles.append(
            Particle(
                x - 14, y + 4,
                random.uniform(-1.5, -0.5), random.uniform(-0.5, 1.0),
                (255, 230, 100), size=4, lifespan=24, shape="feather"
            )
        )

    def spawn_score_sparkles(self, x, y):
        colors = [(255, 235, 80), (255, 255, 255), (255, 180, 50)]
        for _ in range(12):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(2.0, 5.0)
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed
            color = random.choice(colors)
            size = random.randint(3, 5)
            lifespan = random.randint(18, 30)
            self.particles.append(Particle(x, y, vx, vy, color, size, lifespan, shape="sparkle"))

    def spawn_hit_feathers(self, x, y, bird_color=(245, 200, 35)):
        for _ in range(15):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(1.5, 5.5)
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed - 1.5
            size = random.randint(3, 6)
            lifespan = random.randint(30, 50)
            c = bird_color if random.random() > 0.3 else (255, 255, 255)
            self.particles.append(Particle(x, y, vx, vy, c, size, lifespan, shape="feather"))

    def spawn_confetti(self, width, count=30):
        colors = [
            (255, 80, 80), (80, 220, 255), (255, 230, 80),
            (140, 255, 100), (240, 100, 255), (255, 160, 50)
        ]
        for _ in range(count):
            x = random.randint(10, width - 10)
            y = random.randint(-40, 0)
            vx = random.uniform(-1.0, 1.0)
            vy = random.uniform(1.5, 3.5)
            c = random.choice(colors)
            size = random.randint(3, 5)
            lifespan = random.randint(50, 90)
            self.particles.append(Particle(x, y, vx, vy, c, size, lifespan, shape="confetti"))

    def update(self):
        for p in self.particles:
            p.update()
        self.particles = [p for p in self.particles if p.alive]

    def draw(self, surface):
        for p in self.particles:
            p.draw(surface)

    def clear(self):
        self.particles.clear()
