# 🎤 Flappy Bird Clone (PS-45) — Complete Presentation Guide & Viva Notes
**Rungta International Skills University | School of Computer Science & Engineering**  
**Course:** B.Tech CSE (First Semester) | **Project Title:** Flappy Bird Clone (PS No. 45)  
**File Created:** `Flappy_Bird_Presentation_PS45.pptx` (12 Widescreen Slides, 16:9)

---

## 📌 Slide Structure Overview

| Slide # | Slide Title | Visual Contents |
| :---: | :--- | :--- |
| **1** | Title Slide | University Name, Dept, Project Title, Tech Badges, Game Screenshot |
| **2** | Project Overview & Objectives | Problem Goal, Key Concepts, Rigorous Verification |
| **3** | Exact Specifications (PS-45) | Parameter Table (400x600, 30x30, y=600), Termination Rules |
| **4** | Architecture & Pygame Loop | 4-Step Cycle: Event Polling ➔ Physics ➔ Collision ➔ Render/Sync |
| **5** | Physics & Discrete Euler Integration | Kinematic Equations, Step-by-Step Simulation Numerical Trace |
| **6** | Collision Detection (AABB) | Pipe Collision (`colliderect`), Ground (`>= 600`), Ceiling (`< 0`) |
| **7** | Pipe Generation & Scoring Logic | 90-Frame Spawn, Traversability Margin Math, Edge Score Trigger |
| **8** | Automated Test Cases (PS-45) | Complete Table: TC-1, TC-2a, TC-2b, TC-3, TC-4 (All Passed) |
| **9** | GUI & Visual Assets | Gameplay & Game Over Screenshots, Pixel Art, Retro Shading |
| **10** | OOP Design & Code Structure | Class breakdown: `Bird`, `Pipe`, `FlappyBirdGame` |
| **11** | Key Learnings & Future Scope | Academic Takeaways & 4 Future Extensions (SFX, AI NEAT, etc.) |
| **12** | Conclusion & Q&A | Thank You, Summary, Q&A Invitation |

---

## 🗣️ Slide-by-Slide Speaking Script (English & Hinglish)

### Slide 1: Title Slide
- **English:** "Good morning/afternoon respected professors and evaluators. Today I am presenting my First Semester Computer Science project: 'Flappy Bird Clone', developed strictly according to University Problem Statement No. 45 using Python 3 and Pygame."
- **Hinglish:** "Respected teachers, aaj main apna First Semester B.Tech CSE project present kar raha hoon jiska title hai 'Flappy Bird Clone'. Yeh project university ke Problem Statement No. 45 par based hai jise maine Python 3 aur Pygame library use karke design kiya hai."

---

### Slide 2: Project Overview & Objectives
- **English:** "The objective of this project is to model a real-time, 2D arcade physics game. We implement continuous gravity, instantaneous jump impulses via the SPACE key, procedural obstacle generation, and precise collision detection while maintaining a smooth 60 FPS refresh rate."
- **Hinglish:** "Is project ka main objective real-time 2D physics simulate karna hai. Bird par continuous gravity act karti hai aur user SPACE key se jump kar sakta hai. Isme procedural pipe generation aur strict collision detection implement ki gayi hai bina kisi lag ke."

---

### Slide 3: Exact Specifications (PS No. 45)
- **English:** "Our implementation adheres 100% to the university constraints:
  - Game window is fixed at 400x600 pixels.
  - The bird is 30x30 pixels, starting at coordinates (100, 300).
  - Gravity accelerates the bird by +1 pixel/frame² downward.
  - Pressing SPACE sets velocity to -10 before updating the frame.
  - Pipes have a width of 60 pixels with a constant 150-pixel vertical clearance gap."
- **Hinglish:** "Hamare project ke saare parameters university PS-45 se match karte hain: screen 400x600 px hai, bird 30x30 px ki hai jo x=100 aur y=300 par start hoti hai. Har frame par gravity velocity me +1 add karti hai aur SPACE dabane par velocity -10 set ho jaati hai."

---

### Slide 4: System Architecture & The Game Loop
- **English:** "The entire game is orchestrated using a deterministic game loop executed at 60 FPS:
  1. Event Polling: Checks input events (SPACE for flap, ESC/QUIT for exit).
  2. Physics Update: Applies acceleration and integrates position.
  3. Collision & Scoring: Tests bounding boxes and boundary limits.
  4. Rendering: Clears the display, draws scenery, pipes, bird, HUD, and swaps buffers using `pygame.display.flip()`."
- **Hinglish:** "Game loop 4 phases me execute hota hai 60 FPS par: Pehle user ka key input capture hota hai, fir physics update hoti hai, uske baad collision aur score check hota hai, aur end me screen render karke buffer swap hota hai."

---

### Slide 5: Physics Engine: Discrete Euler Integration
- **English:** "We use discrete Euler numerical integration:
  - Velocity formula: $v_{t+1} = v_t + 1$
  - Position formula: $y_{t+1} = y_t + v_{t+1}$
  When falling freely from rest at $y=300$, in Frame 1 velocity becomes 1 and position becomes 301. In Frame 2, velocity becomes 2 and position becomes 303. This produces a natural parabolic trajectory."
- **Hinglish:** "Physics me discrete Euler integration use hui hai. Gravitational acceleration $1\\text{ px/frame}^2$ hai. Free fall me bird $y=300$ se $301$ aur fir $303$ par aati hai. Aur jab player SPACE press karta hai to velocity jump karke upward trajectory banati hai."

---

### Slide 6: Collision Detection Mechanism (AABB)
- **English:** "We enforce three distinct termination boundaries:
  1. Pipe Obstacles: Using Pygame's `Rect.colliderect()` algorithm which evaluates Axis-Aligned Bounding Box overlaps.
  2. Ground Boundary: If `bird.bottom >= 600`, ground collision is flagged.
  3. Ceiling Boundary: If `bird.top < 0`, top exit collision is flagged."
- **Hinglish:** "Collision detection ke 3 criteria hain: Pehla, pipes ke saath `Rect.colliderect()`. Doosra, ground collision jab bird ka bottom 600 touch karta hai. Teesri, screen ka top edge (y < 0) jahan se bird bahar nahi ja sakti."

---

### Slide 7: Pipe Generation & Scoring Logic
- **English:** "Pipes spawn every 90 frames (~1.5 seconds). To guarantee the player can always navigate through, we leave at least 50px of visible pipe at both top and bottom. A point is scored when a pipe's right edge passes the bird's horizontal position (`pipe.x + 60 < 100`). Once passed, a boolean flag prevents duplicate scoring."
- **Hinglish:** "Pipes har 1.5 second (90 frames) me spawn hote hain. 150px ka gap randomly position hota hai safety margin ke sath. Jaise hi pipe bird ko cross karta hai (`pipe.x + 60 < 100`), score me +1 add hota hai aur duplicate score avoid karne ke liye `pipe.passed = True` mark kar diya jata hai."

---

### Slide 8: Automated University Test Suite (PS-45)
- **English:** "We developed an automated test suite verifying all 4 scenarios from the university question paper:
  - TC-1: Normal free fall (F1: v=1, y=301; F2: v=2, y=303) — PASSED
  - TC-2a: Ground collision at y=570 — PASSED
  - TC-2b: Top screen exit at y=5 with SPACE pressed (v=-9, y=-4) — PASSED
  - TC-3: Invalid keystroke 'Z' safely ignored — PASSED
  - TC-4: Flap under downward motion & pipe passing at x=39 — PASSED
  All 4 test cases pass with 100% strict adherence."
- **Hinglish:** "Hamare code me automated test cases embedded hain jo question paper ke charo scenarios ko verify karte hain: Normal Input, Boundary conditions (Ground & Ceiling), Invalid Input ('Z' key ignored), aur Valid Scenarios (Flap movement & Score count). Saare test cases 100% PASS hote hain."

---

### Slide 9: Graphical User Interface & Visuals
- **English:** "We designed a polished retro arcade visual aesthetic: custom 30x30 bird sprite with eye, beak, and flapping wing; 3D-shaded green pipes with highlights and rims; layered skyline backdrop; and a crisp Game Over modal."
- **Hinglish:** "Game visuals ko arcade feel diya gaya hai: 30x30 retro bird sprite, 3D style shaded pipes with highlights, city skyline background, aur semi-transparent Game Over popup."

---

### Slide 10: OOP Architecture
- **English:** "The codebase is cleanly structured into three Object-Oriented classes:
  - `Bird`: State, velocity, rect coordinates, flap method, and physics update.
  - `Pipe`: Dual top and bottom rects, movement speed, and collision test.
  - `FlappyBirdGame`: Main controller managing clock, events, scores, and screen rendering."
- **Hinglish:** "Code ko 3 main classes me divide kiya gaya hai: `Bird` class jo physics aur jump manage karti hai, `Pipe` class jo obstacles aur movement manage karti hai, aur `FlappyBirdGame` class jo master loop aur rendering handle karti hai."

---

### Slide 11: Academic Learnings & Future Scope
- **English:** "This project gave us practical insights into 2D kinematics, bounding box algorithms, and event-driven architecture. In the future, this can be extended with procedural sound synthesizers, persistent leaderboards, and AI agents using NEAT genetic algorithms."
- **Hinglish:** "Is project se hume computer graphics, 2D physics integration aur event-driven programming ka real-world experience mila. Future me hum isme sound effects, database leaderboard aur AI auto-play add kar sakte hain."

---

### Slide 12: Conclusion & Q&A
- **English:** "Thank you for your time and attention. I am now open to any questions, and I am ready to demonstrate the live game and automated test suite."
- **Hinglish:** "Thank you teachers! Ab aap koi bhi questions pooch sakte hain aur main live game demo aur test suite run karke dikhane ke liye ready hoon."

---

## 💡 Top 5 Expected Viva Questions & Best Answers

1. **Q: How does gravity work in your game?**  
   *Ans:* "It uses discrete Euler integration. Every frame, downward acceleration ($g = 1\text{ px/frame}^2$) is added to velocity (`velocity += 1`), and then position is updated by that velocity (`y += velocity`)."

2. **Q: Why did you use `Rect.colliderect` instead of pixel-perfect collision?**  
   *Ans:* "Because both the bird (30x30) and pipes (60px rectangular columns) are Axis-Aligned Bounding Boxes. AABB collision check is $O(1)$ and runs efficiently at 60 FPS without unnecessary CPU overhead."

3. **Q: How do you prevent memory leaks when thousands of pipes are generated?**  
   *Ans:* "We implement off-screen pruning: any pipe whose right boundary is off-screen (`pipe.x + pipe.width < 0`) is automatically filtered out from `self.pipes`."

4. **Q: How do you test the code without opening a window?**  
   *Ans:* "We implemented a headless mode: running `python flappy_bird.py --test` or `python test_flappy_bird.py` sets `headless=True` and runs unit assertions on physics, collisions, and scoring without requiring a display server."

5. **Q: What happens if a player presses any key other than SPACE?**  
   *Ans:* "In `handle_input()`, only `pygame.K_SPACE` triggers `bird.flap()`. Any other key (e.g. 'Z') is completely ignored, satisfying Test Case 3 of PS-45."
