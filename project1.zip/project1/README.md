# 🎮 Flappy Bird Clone — PS No. 45
### Rungta International Skills University — School of Computer Science & Engineering
### B.Tech Computer Science and Engineering (First Semester)

---

## 📋 Problem Statement Summary

- **Window**: `400 x 600`
- **Bird**: `30 x 30` at `x = 100`, starts at `y = 300`
- **Physics**:
  - Each frame: `velocity += 1`, then `y += velocity`
  - `SPACE` sets `velocity = -10` before the frame update
- **Pipes**: `60 px` wide with a `150 px` gap
- **Ground**: at `y = 600`
- **Collisions**: Detected using `Rect.colliderect()` for pipes, bottom edge $\ge 600$ for ground, and top edge $< 0$ for top screen exit.
- **Single File Requirement**: Complete solution in a single Python file: [`flappy_bird.py`](flappy_bird.py).

---

## 🚀 Quick Start (Kaise Chalayein)

### 1. Game Start Karein (GUI Mode)
```powershell
python flappy_bird.py
```
*(Ya fir `python main.py`)*

### 2. University Test Cases Run Karein (Automated Test Mode)
```powershell
python flappy_bird.py --test
```
Ya standard unittest:
```powershell
python -m unittest test_flappy_bird.py
```

---

## 🕹️ Controls

| Key | Action |
| :--- | :--- |
| **SPACE** / **Mouse Click** | Bird Flap (Udaan) |
| **SPACE** (on Game Over) | Restart Game |
| **ESC** | Exit Game |

---

## ✅ Test Cases Verification

| Test Case | Scenario | Expected Output | Status |
| :--- | :--- | :--- | :---: |
| **Test Case 1** | Normal Input ($y=300, v=0$, 2 frames) | Frame 1: $v=1, y=301$<br>Frame 2: $v=2, y=303$ | **PASSED** |
| **Test Case 2 (a)** | Boundary ($y=570$, bottom touches 600) | Collision with ground \| Game Over | **PASSED** |
| **Test Case 2 (b)** | Boundary ($y=5, v=0$, SPACE pressed) | $v=-9, y=-4$ \| Bird left screen at top \| Game Over | **PASSED** |
| **Test Case 3** | Invalid Input (Key `Z` pressed) | Key ignored \| $v=1, y=301$ | **PASSED** |
| **Test Case 4 (a)** | Valid Scenario ($y=300, v=5$, SPACE pressed) | $v=-9, y=291$ (bird moves up) | **PASSED** |
| **Test Case 4 (b)** | Valid Scenario (Pipe at $x=39$, bird at $x=100$) | Pipe passed \| Score: 1 | **PASSED** |

---

## 📄 Project Report & GitHub Submission
Complete formal university project documentation is available in [`PROJECT_REPORT.md`](PROJECT_REPORT.md).
