# PROJECT REPORT
## Bachelor of Technology (Computer Science and Engineering) — First Semester
### RUNGTA INTERNATIONAL SKILLS UNIVERSITY
### SCHOOL OF COMPUTER SCIENCE AND ENGINEERING

---

| **Item** | **Details** |
| :--- | :--- |
| **PS No.** | **45** |
| **Project Title** | **Flappy Bird Clone** |
| **Course** | B.Tech CSE — 1st Semester |
| **Language** | Python 3 |
| **Key Concepts** | Pygame, Gravity, Collision Detection (`Rect.colliderect`), Game Loop |

---

## 1. Problem Statement

Create a Flappy Bird style game in which a bird constantly falls due to gravity and flies upward when the player presses `SPACE`. The player must pass through gaps between pipes to score, and the game ends if the bird hits a pipe, the ground, or leaves the top of the screen.

### Exact Specifications:
- **Window Dimensions**: `400 x 600` pixels
- **Bird Dimensions & Position**: `30 x 30` pixels, located at `x = 100`, starting at `y = 300`
- **Physics Formula**:
  - Each frame: `velocity += 1`, then `y += velocity`
  - When `SPACE` is pressed: sets `velocity = -10` before the frame update
- **Pipes**:
  - Width: `60 px`
  - Gap: `150 px`
- **Ground Level**: `y = 600`
- **Single File Implementation**: Solution contained in one standalone `.py` file (`flappy_bird.py`).

---

## 2. Core Concepts & Implementation Architecture

### 2.1 The Game Loop
The application runs a continuous game loop managed by `pygame.time.Clock()` at 60 FPS:
1. **Event Handling**: Checks for window close and keyboard events (`pygame.KEYDOWN`).
2. **Physics Update**:
   - Velocity increments by gravitational acceleration ($g = 1\text{ px/frame}^2$).
   - Vertical position updates by velocity ($\Delta y = v$).
3. **Collision Detection**:
   - `bird_rect.bottom >= 600` $\rightarrow$ Ground collision
   - `bird_rect.top < 0` $\rightarrow$ Top boundary exit
   - `bird_rect.colliderect(pipe.top_rect)` or `bird_rect.colliderect(pipe.bot_rect)` $\rightarrow$ Pipe obstacle collision
4. **Scoring Logic**:
   - When a pipe's right boundary ($x + \text{width} = x + 60$) becomes strictly less than the bird's horizontal position ($x = 100$), and the pipe has not been previously scored, the score increments by $+1$.
5. **Rendering**:
   - Screen background, pipes, ground line, bird, and HUD score counter are redrawn every frame.

---

## 3. Test Cases & Verification Results

The table below documents the verification of all 4 test cases specified in the university problem statement:

| **Test Case** | **Scenario** | **Input Parameters** | **Expected Output** | **Actual Output** | **Status** |
| :--- | :--- | :--- | :--- | :--- | :---: |
| **TC-1** | Normal Input | Bird $y = 300, v = 0$, No key pressed, 2 frames | Frame 1: $v = 1, y = 301$<br>Frame 2: $v = 2, y = 303$ | Frame 1: $v = 1, y = 301$<br>Frame 2: $v = 2, y = 303$ | **PASSED** |
| **TC-2 (a)** | Boundary / Min Input | Bird $y = 570$ (bottom edge touches $y = 600$) | Collision with ground \| Game Over | Collision with ground \| Game Over | **PASSED** |
| **TC-2 (b)** | Boundary / Min Input | Bird $y = 5, v = 0$, `SPACE` pressed, 1 frame | $v = -9, y = -4$ \| Bird left screen at top \| Game Over | $v = -9, y = -4$ \| Bird left screen at top \| Game Over | **PASSED** |
| **TC-3** | Invalid Input | Bird $y = 300, v = 0$, Key pressed: `Z` (not SPACE), 1 frame | Key ignored \| $v = 1, y = 301$ | Key ignored \| $v = 1, y = 301$ | **PASSED** |
| **TC-4 (a)** | Different Valid Scenario | Bird $y = 300, v = 5$, `SPACE` pressed, 1 frame | $v = -9, y = 291$ (bird moves up) | $v = -9, y = 291$ (bird moves up) | **PASSED** |
| **TC-4 (b)** | Different Valid Scenario | Pipe at $x = 39$ (width 60), bird $x = 100$, score $= 0$ | Pipe passed \| Score: 1 | Pipe passed \| Score: 1 | **PASSED** |

---

## 4. How to Execute

### 4.1 Running the Interactive Game
To play the game in the graphical Pygame window:
```powershell
python flappy_bird.py
```
*(Or via `python main.py`)*

**Controls**:
- `SPACE` / `Left Mouse Click` : Flap wings / Restart after Game Over
- `ESC` : Exit game

### 4.2 Running the Automated Test Suite
To execute the automated verification of all 4 university test cases:
```powershell
python flappy_bird.py --test
```
Or run the Python standard unittest suite:
```powershell
python -m unittest test_flappy_bird.py
```

---

## 5. GitHub Submission Guide

Follow these commands to push the project to your GitHub repository:

```powershell
# 1. Initialize git repository
git init

# 2. Stage all project files
git add .

# 3. Commit the code
git commit -m "Flappy Bird Clone - PS No. 45 Solution and Report"

# 4. Link your remote repository (replace with your GitHub repo URL)
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git

# 5. Push to GitHub
git push -u origin main
```
