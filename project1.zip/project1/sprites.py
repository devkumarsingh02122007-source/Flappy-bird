import pygame
import math
import random
from constants import (
    SCREEN_WIDTH, SCREEN_HEIGHT, GROUND_HEIGHT,
    PIPE_WIDTH, SKIN_COLORS, SKIN_NAMES
)

def create_gradient_surface(width, height, top_color, bottom_color):
    """Creates a smooth vertical gradient surface."""
    surf = pygame.Surface((width, height))
    for y in range(height):
        ratio = y / max(1, height - 1)
        r = int(top_color[0] + (bottom_color[0] - top_color[0]) * ratio)
        g = int(top_color[1] + (bottom_color[1] - top_color[1]) * ratio)
        b = int(top_color[2] + (bottom_color[2] - top_color[2]) * ratio)
        pygame.draw.line(surf, (r, g, b), (0, y), (width, y))
    return surf

def create_bird_surfaces(skin_key):
    """
    Creates 3 animation frames for a bird skin:
    0: wing up, 1: wing mid, 2: wing down
    """
    colors = SKIN_COLORS.get(skin_key, SKIN_COLORS["classic"])
    frames = []
    
    w, h = 44, 32
    body_color = colors["body"]
    belly_color = colors["belly"]
    wing_color = colors["wing"]
    outline = colors["outline"]
    beak_color = colors["beak"]
    beak_hi = colors["beak_highlight"]
    cheek_color = colors["cheek"]
    
    wing_positions = [
        # Up
        [(-4, -6), (-14, -14), (-18, -4), (-10, 2)],
        # Mid
        [(-2, 0), (-14, -4), (-16, 6), (-6, 6)],
        # Down
        [(0, 4), (-10, 8), (-14, 14), (-4, 12)]
    ]
    
    for wing_pts_offset in wing_positions:
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        
        # Center of bird body
        cx, cy = 20, 16
        
        # Tail feather
        tail = [(cx - 16, cy + 2), (cx - 24, cy - 4), (cx - 22, cy + 4), (cx - 24, cy + 8)]
        pygame.draw.polygon(surf, outline, tail)
        pygame.draw.polygon(surf, wing_color, [(p[0] + 1, p[1]) for p in tail[:3]])
        
        # Main Body (oval with outline)
        body_rect = pygame.Rect(cx - 16, cy - 12, 30, 24)
        pygame.draw.ellipse(surf, outline, body_rect)
        inner_body = pygame.Rect(cx - 14, cy - 10, 26, 20)
        pygame.draw.ellipse(surf, body_color, inner_body)
        
        # Belly highlight
        belly_rect = pygame.Rect(cx - 10, cy + 1, 16, 8)
        pygame.draw.ellipse(surf, belly_color, belly_rect)
        
        # Wing
        actual_wing = [(cx + ox, cy + oy) for ox, oy in wing_pts_offset]
        pygame.draw.polygon(surf, outline, actual_wing)
        inner_wing = [
            (int((p[0] * 3 + cx) / 4), int((p[1] * 3 + cy) / 4))
            for p in actual_wing
        ]
        pygame.draw.polygon(surf, wing_color, inner_wing)
        
        # Cheek Blush
        blush_surf = pygame.Surface((8, 6), pygame.SRCALPHA)
        blush_surf.fill(cheek_color)
        surf.blit(blush_surf, (cx + 1, cy + 2))
        
        # Eye (White outer, black pupil, tiny specular highlight)
        eye_center = (cx + 6, cy - 4)
        pygame.draw.circle(surf, outline, eye_center, 6)
        pygame.draw.circle(surf, (255, 255, 255), eye_center, 5)
        # Pupil
        pygame.draw.circle(surf, (20, 20, 30), (cx + 8, cy - 4), 3)
        # Glint
        pygame.draw.circle(surf, (255, 255, 255), (cx + 9, cy - 6), 1)
        
        # Beak
        beak_poly = [
            (cx + 8, cy - 1),
            (cx + 20, cy + 2),
            (cx + 9, cy + 8),
            (cx + 6, cy + 4)
        ]
        pygame.draw.polygon(surf, outline, beak_poly)
        inner_beak = [(p[0] - 1, p[1]) for p in beak_poly]
        pygame.draw.polygon(surf, beak_color, inner_beak)
        # Beak highlight & split line
        pygame.draw.line(surf, beak_hi, (cx + 9, cy + 1), (cx + 18, cy + 2), 2)
        pygame.draw.line(surf, outline, (cx + 7, cy + 3), (cx + 18, cy + 3), 1)
        
        frames.append(surf)
        
    return frames

def create_pipe_surfaces(width=PIPE_WIDTH, height=500):
    """Creates top and bottom pipe surfaces with realistic retro shading and bevel."""
    cap_height = 28
    cap_overhang = 4
    cap_width = width + cap_overhang * 2
    
    # Bottom pipe surface
    pipe_surf = pygame.Surface((cap_width, height), pygame.SRCALPHA)
    
    # Colors
    c_outline = (35, 75, 20)
    c_dark = (55, 120, 25)
    c_mid = (95, 175, 35)
    c_light = (135, 215, 55)
    c_highlight = (185, 240, 110)
    
    # 1. Pipe Body (x offset = cap_overhang)
    bx = cap_overhang
    bw = width
    body_rect = pygame.Rect(bx, cap_height, bw, height - cap_height)
    pygame.draw.rect(pipe_surf, c_mid, body_rect)
    
    # Highlights & shadows for body
    pygame.draw.line(pipe_surf, c_highlight, (bx + 4, cap_height), (bx + 4, height), 3)
    pygame.draw.line(pipe_surf, c_light, (bx + 9, cap_height), (bx + 9, height), 4)
    pygame.draw.line(pipe_surf, c_dark, (bx + bw - 6, cap_height), (bx + bw - 6, height), 6)
    
    # Body outline
    pygame.draw.rect(pipe_surf, c_outline, body_rect, 2)
    
    # 2. Pipe Cap
    cap_rect = pygame.Rect(0, 0, cap_width, cap_height)
    pygame.draw.rect(pipe_surf, c_mid, cap_rect)
    
    # Cap shading
    pygame.draw.line(pipe_surf, c_highlight, (4, 2), (4, cap_height - 2), 4)
    pygame.draw.line(pipe_surf, c_light, (10, 2), (10, cap_height - 2), 5)
    pygame.draw.line(pipe_surf, c_dark, (cap_width - 8, 2), (cap_width - 8, cap_height - 2), 8)
    
    # Cap inner bevel
    pygame.draw.line(pipe_surf, c_highlight, (1, 1), (cap_width - 2, 1), 2)
    pygame.draw.line(pipe_surf, c_dark, (1, cap_height - 2), (cap_width - 2, cap_height - 2), 2)
    
    # Cap outline
    pygame.draw.rect(pipe_surf, c_outline, cap_rect, 2)
    
    # Top pipe is simply vertically flipped!
    top_pipe_surf = pygame.transform.flip(pipe_surf, False, True)
    
    return top_pipe_surf, pipe_surf

def create_ground_surface(width=SCREEN_WIDTH, height=GROUND_HEIGHT):
    """Creates a seamless scrolling ground with retro grass hazard stripes."""
    surf_width = width + 60  # Extra width for smooth wrap
    surf = pygame.Surface((surf_width, height))
    
    # Earth colors
    c_earth = (222, 214, 150)
    c_earth_shadow = (200, 190, 130)
    c_grass_light = (115, 205, 45)
    c_grass_dark = (85, 160, 30)
    c_outline = (60, 45, 25)
    
    # Base fill
    surf.fill(c_earth)
    
    # Earth pebble details
    random.seed(42)
    for _ in range(60):
        px = random.randint(0, surf_width - 6)
        py = random.randint(22, height - 8)
        pw = random.randint(3, 7)
        ph = random.randint(2, 4)
        pygame.draw.ellipse(surf, c_earth_shadow, (px, py, pw, ph))
        
    # Grass Top Bar (16px high)
    grass_h = 16
    stripe_w = 16
    for x in range(-stripe_w, surf_width + stripe_w, stripe_w):
        pts = [
            (x, 0),
            (x + stripe_w, 0),
            (x + stripe_w - 8, grass_h),
            (x - 8, grass_h)
        ]
        color = c_grass_light if (x // stripe_w) % 2 == 0 else c_grass_dark
        pygame.draw.polygon(surf, color, pts)
        
    # Border line below grass
    pygame.draw.line(surf, c_outline, (0, 0), (surf_width, 0), 3)
    pygame.draw.line(surf, c_outline, (0, grass_h), (surf_width, grass_h), 2)
    
    return surf

def create_backgrounds():
    """Generates the 3 themes: Day, Sunset, Night with parallax clouds and silhouettes."""
    themes = {}
    
    # 1. DAY THEME
    day_surf = create_gradient_surface(
        SCREEN_WIDTH, SCREEN_HEIGHT - GROUND_HEIGHT + 10,
        (78, 192, 202), (200, 240, 248)
    )
    # Clouds on day
    _draw_clouds(day_surf, (255, 255, 255), (230, 245, 250))
    # Hills & City
    _draw_city_silhouette(day_surf, (150, 215, 170), (130, 195, 150))
    themes["day"] = day_surf
    
    # 2. SUNSET THEME
    sunset_surf = create_gradient_surface(
        SCREEN_WIDTH, SCREEN_HEIGHT - GROUND_HEIGHT + 10,
        (55, 30, 85), (245, 135, 80)
    )
    _draw_clouds(sunset_surf, (255, 175, 130), (220, 110, 90))
    _draw_city_silhouette(sunset_surf, (80, 45, 85), (55, 30, 60), lit_windows=True)
    themes["sunset"] = sunset_surf
    
    # 3. NIGHT THEME
    night_surf = create_gradient_surface(
        SCREEN_WIDTH, SCREEN_HEIGHT - GROUND_HEIGHT + 10,
        (12, 16, 42), (32, 45, 95)
    )
    # Stars
    random.seed(101)
    for _ in range(50):
        sx = random.randint(5, SCREEN_WIDTH - 5)
        sy = random.randint(5, 260)
        brightness = random.randint(180, 255)
        pygame.draw.circle(night_surf, (brightness, brightness, brightness), (sx, sy), 1 if brightness < 230 else 2)
    # Moon
    _draw_moon(night_surf, SCREEN_WIDTH - 65, 55)
    _draw_clouds(night_surf, (50, 65, 110, 180), (35, 45, 85, 180))
    _draw_city_silhouette(night_surf, (22, 28, 55), (15, 20, 40), lit_windows=True)
    themes["night"] = night_surf
    
    return themes

def _draw_clouds(surf, color1, color2):
    """Draws stylish cartoon clouds."""
    cloud_data = [
        (45, 90, 70), (180, 60, 90), (310, 110, 65)
    ]
    for cx, cy, sz in cloud_data:
        c_surf = pygame.Surface((sz * 2, sz), pygame.SRCALPHA)
        # Shadow circles
        pygame.draw.circle(c_surf, color2, (sz // 2, sz // 2 + 2), sz // 3)
        pygame.draw.circle(c_surf, color2, (sz, sz // 2 - 4 + 2), sz // 2)
        pygame.draw.circle(c_surf, color2, (sz + sz // 2, sz // 2 + 2), sz // 3)
        # Main circles
        pygame.draw.circle(c_surf, color1, (sz // 2, sz // 2), sz // 3)
        pygame.draw.circle(c_surf, color1, (sz, sz // 2 - 4), sz // 2)
        pygame.draw.circle(c_surf, color1, (sz + sz // 2, sz // 2), sz // 3)
        pygame.draw.rect(c_surf, color1, (sz // 3, sz // 2, sz + sz // 3, sz // 3))
        surf.blit(c_surf, (cx, cy))

def _draw_moon(surf, x, y):
    """Draws a glowing crescent moon."""
    # Glow
    glow = pygame.Surface((60, 60), pygame.SRCALPHA)
    pygame.draw.circle(glow, (255, 255, 210, 35), (30, 30), 28)
    pygame.draw.circle(glow, (255, 255, 230, 70), (30, 30), 20)
    surf.blit(glow, (x - 30, y - 30))
    
    # Moon base
    pygame.draw.circle(surf, (255, 255, 220), (x, y), 16)
    # Shadow crescent cutout
    pygame.draw.circle(surf, (20, 28, 65), (x - 6, y - 4), 14)

def _draw_city_silhouette(surf, far_color, near_color, lit_windows=False):
    """Draws distant buildings and city skyline."""
    base_y = SCREEN_HEIGHT - GROUND_HEIGHT
    
    # Far Layer
    random.seed(99)
    x = 0
    while x < SCREEN_WIDTH:
        bw = random.randint(28, 48)
        bh = random.randint(45, 95)
        rect = pygame.Rect(x, base_y - bh, bw, bh)
        pygame.draw.rect(surf, far_color, rect)
        x += bw + random.randint(2, 8)
        
    # Near Layer
    random.seed(55)
    x = 0
    while x < SCREEN_WIDTH:
        bw = random.randint(22, 42)
        bh = random.randint(25, 65)
        rect = pygame.Rect(x, base_y - bh, bw, bh)
        pygame.draw.rect(surf, near_color, rect)
        
        # Windows
        if lit_windows:
            for wx in range(x + 5, x + bw - 5, 8):
                for wy in range(base_y - bh + 6, base_y - 6, 10):
                    if random.random() > 0.4:
                        pygame.draw.rect(surf, (255, 230, 120), (wx, wy, 3, 4))
        x += bw + random.randint(4, 12)

def create_medal(medal_type):
    """Generates a shiny arcade medal surface."""
    surf = pygame.Surface((44, 44), pygame.SRCALPHA)
    cx, cy = 22, 22
    
    colors = {
        "bronze": ((190, 110, 50), (225, 155, 90), (140, 75, 30)),
        "silver": ((195, 205, 215), (240, 245, 250), (145, 155, 165)),
        "gold": ((245, 190, 30), (255, 235, 110), (195, 140, 15)),
        "platinum": ((130, 220, 240), (215, 250, 255), (80, 170, 200))
    }
    
    main_c, hi_c, dark_c = colors.get(medal_type, colors["bronze"])
    
    # Outer dark rim
    pygame.draw.circle(surf, (40, 40, 40), (cx, cy), 20)
    # Bevel
    pygame.draw.circle(surf, dark_c, (cx, cy), 19)
    pygame.draw.circle(surf, main_c, (cx, cy), 17)
    # Shiny upper-left reflection
    pygame.draw.circle(surf, hi_c, (cx - 4, cy - 4), 9)
    pygame.draw.circle(surf, main_c, (cx, cy), 13)
    
    # Center Star
    pts = []
    for i in range(10):
        angle = i * (math.pi / 5) - math.pi / 2
        r = 8 if i % 2 == 0 else 4
        pts.append((cx + int(r * math.cos(angle)), cy + int(r * math.sin(angle))))
    pygame.draw.polygon(surf, hi_c, pts)
    pygame.draw.polygon(surf, dark_c, pts, 1)
    
    return surf
