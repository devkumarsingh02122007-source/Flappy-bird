"""
Unit Tests for Flappy Bird Clone (PS No. 45)
Rungta International Skills University - School of Computer Science & Engineering
"""

import unittest
from flappy_bird import Bird, Pipe, FlappyBirdGame, WINDOW_WIDTH, GROUND_Y

class TestFlappyBirdPS45(unittest.TestCase):

    def test_case_1_normal_input(self):
        """
        Test Case 1: Normal Input
        Input: Bird y = 300, velocity = 0, No key pressed, 2 frames
        Expected Output:
          Frame 1: velocity = 1 | y = 301
          Frame 2: velocity = 2 | y = 303
        """
        bird = Bird(x=100, y=300)
        bird.velocity = 0

        # Frame 1
        bird.update_physics()
        self.assertEqual(bird.velocity, 1)
        self.assertEqual(bird.y, 301)

        # Frame 2
        bird.update_physics()
        self.assertEqual(bird.velocity, 2)
        self.assertEqual(bird.y, 303)

    def test_case_2a_ground_collision(self):
        """
        Test Case 2(a): Boundary / Minimum Input
        Input: Bird y = 570 (bottom edge touches y = 600)
        Expected Output: Collision with ground | Game Over
        """
        game = FlappyBirdGame(headless=True)
        game.bird.y = 570
        game.bird.rect.topleft = (100, 570)
        self.assertEqual(game.bird.rect.bottom, 600)
        
        has_collided = game.check_collisions()
        self.assertTrue(has_collided)
        self.assertTrue(game.game_over)
        self.assertIn("ground", game.game_over_reason.lower())

    def test_case_2b_top_edge_collision(self):
        """
        Test Case 2(b): Boundary / Minimum Input
        Input: Bird y = 5, velocity = 0, SPACE pressed
        Expected Output: velocity = -9 | y = -4 | Bird left the screen at the top | Game Over
        """
        import pygame
        game = FlappyBirdGame(headless=True)
        game.bird.y = 5
        game.bird.velocity = 0
        game.bird.rect.topleft = (100, 5)

        # SPACE sets velocity = -10 before frame update
        game.handle_input(pygame.K_SPACE)
        self.assertEqual(game.bird.velocity, -10)

        # 1 frame update
        game.update_frame()
        self.assertEqual(game.bird.velocity, -9)
        self.assertEqual(game.bird.y, -4)
        self.assertTrue(game.game_over)
        self.assertIn("top", game.game_over_reason.lower())

    def test_case_3_invalid_input(self):
        """
        Test Case 3: Invalid Input
        Input: Bird y = 300, velocity = 0, Key pressed: Z (not SPACE), 1 frame
        Expected Output: Key ignored | velocity = 1 | y = 301
        """
        import pygame
        game = FlappyBirdGame(headless=True)
        game.bird.y = 300
        game.bird.velocity = 0

        game.handle_input(pygame.K_z)
        game.update_frame()

        self.assertEqual(game.bird.velocity, 1)
        self.assertEqual(game.bird.y, 301)

    def test_case_4a_flap_upward(self):
        """
        Test Case 4(a): Different Valid Scenario
        Input: Bird y = 300, velocity = 5, SPACE pressed, 1 frame
        Expected Output: velocity = -9 | y = 291 (bird moves up)
        """
        bird = Bird(x=100, y=300)
        bird.velocity = 5
        bird.flap()
        self.assertEqual(bird.velocity, -10)

        bird.update_physics()
        self.assertEqual(bird.velocity, -9)
        self.assertEqual(bird.y, 291)

    def test_case_4b_pipe_passed_score(self):
        """
        Test Case 4(b): Different Valid Scenario
        Input: Pipe at x = 39 (width 60), bird x = 100, score = 0
        Expected Output: Pipe passed | Score: 1
        """
        game = FlappyBirdGame(headless=True)
        pipe = Pipe(x=39, gap_y=200)
        game.pipes.append(pipe)
        game.bird.x = 100
        game.score = 0

        # Pipe right edge = 39 + 60 = 99 < 100
        self.assertLess(pipe.x + pipe.width, game.bird.x)
        
        # Scoring logic
        for p in game.pipes:
            if not p.passed and (p.x + p.width) < game.bird.x:
                p.passed = True
                game.score += 1

        self.assertEqual(game.score, 1)

if __name__ == "__main__":
    unittest.main()
