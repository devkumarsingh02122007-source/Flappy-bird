import os
import sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE

def create_deck():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]

    # Color Palette
    C_NAVY = RGBColor(15, 23, 42)        # Slate 900
    C_DARK_BLUE = RGBColor(30, 41, 59)   # Slate 800
    C_ACCENT_BLUE = RGBColor(14, 165, 233) # Sky 500
    C_GREEN = RGBColor(34, 197, 94)      # Emerald 500
    C_DARK_GREEN = RGBColor(22, 101, 52)
    C_GOLD = RGBColor(245, 158, 11)      # Amber 500
    C_RED = RGBColor(239, 68, 68)        # Red 500
    C_LIGHT_BG = RGBColor(248, 250, 252) # Slate 50
    C_CARD_BG = RGBColor(255, 255, 255)  # White
    C_CARD_BORDER = RGBColor(226, 232, 240) # Slate 200
    C_TEXT_DARK = RGBColor(15, 23, 42)
    C_TEXT_MUTED = RGBColor(100, 116, 139)
    C_WHITE = RGBColor(255, 255, 255)

    def add_header(slide, title_text, category_text="RUNGTA INTERNATIONAL SKILLS UNIVERSITY | PS NO. 45"):
        # Category pill / subtitle
        cat_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.7), Inches(0.4))
        tf_cat = cat_box.text_frame
        tf_cat.word_wrap = True
        p_cat = tf_cat.paragraphs[0]
        p_cat.text = category_text.upper()
        p_cat.font.size = Pt(11)
        p_cat.font.bold = True
        p_cat.font.color.rgb = C_ACCENT_BLUE

        # Slide Main Title
        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.7), Inches(11.7), Inches(0.8))
        tf_title = title_box.text_frame
        tf_title.word_wrap = True
        p_title = tf_title.paragraphs[0]
        p_title.text = title_text
        p_title.font.size = Pt(24)
        p_title.font.bold = True
        p_title.font.color.rgb = C_TEXT_DARK

    def set_slide_background(slide, color):
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
        bg.fill.solid()
        bg.fill.fore_color.rgb = color
        bg.line.fill.background()
        return bg

    def add_card(slide, left, top, width, height, bg_color=C_CARD_BG, border_color=C_CARD_BORDER):
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        card.fill.solid()
        card.fill.fore_color.rgb = bg_color
        if border_color:
            card.line.color.rgb = border_color
            card.line.width = Pt(1.5)
        else:
            card.line.fill.background()
        return card

    # =========================================================================
    # SLIDE 1: Title Slide (Dark Theme)
    # =========================================================================
    s1 = prs.slides.add_slide(blank_layout)
    set_slide_background(s1, C_NAVY)

    # Accent decorative bar
    bar = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.0), Inches(0.15), Inches(5.5))
    bar.fill.solid()
    bar.fill.fore_color.rgb = C_GOLD
    bar.line.fill.background()

    # University & Department
    univ_box = s1.shapes.add_textbox(Inches(1.2), Inches(1.0), Inches(11), Inches(0.8))
    tf1 = univ_box.text_frame
    p1 = tf1.paragraphs[0]
    p1.text = "RUNGTA INTERNATIONAL SKILLS UNIVERSITY"
    p1.font.size = Pt(16)
    p1.font.bold = True
    p1.font.color.rgb = C_ACCENT_BLUE

    p1_sub = tf1.add_paragraph()
    p1_sub.text = "SCHOOL OF COMPUTER SCIENCE AND ENGINEERING | B.Tech CSE - 1st Semester"
    p1_sub.font.size = Pt(13)
    p1_sub.font.color.rgb = RGBColor(148, 163, 184)

    # Main Title
    title_box = s1.shapes.add_textbox(Inches(1.2), Inches(2.1), Inches(11), Inches(2.2))
    tf_m = title_box.text_frame
    pm = tf_m.paragraphs[0]
    pm.text = "FLAPPY BIRD CLONE"
    pm.font.size = Pt(44)
    pm.font.bold = True
    pm.font.color.rgb = C_WHITE

    pm_sub = tf_m.add_paragraph()
    pm_sub.text = "Problem Statement No. 45 (PS-45) | Python 3 & Pygame Engine"
    pm_sub.font.size = Pt(20)
    pm_sub.font.color.rgb = C_GOLD

    # Description summary
    desc_box = s1.shapes.add_textbox(Inches(1.2), Inches(4.3), Inches(8.5), Inches(1.0))
    tfd = desc_box.text_frame
    tfd.word_wrap = True
    pd = tfd.paragraphs[0]
    pd.text = "A physics-driven 2D arcade game implementing gravity acceleration, discrete collision detection (AABB), infinite procedural pipe generation, and 100% compliant test case verification."
    pd.font.size = Pt(14)
    pd.font.color.rgb = RGBColor(203, 213, 225)

    # Presentation details card
    details_card = add_card(s1, Inches(1.2), Inches(5.6), Inches(11.0), Inches(1.3), C_DARK_BLUE, C_ACCENT_BLUE)
    det_box = s1.shapes.add_textbox(Inches(1.4), Inches(5.7), Inches(10.6), Inches(1.1))
    tfd2 = det_box.text_frame
    p_info = tfd2.paragraphs[0]
    p_info.text = "Course: B.Tech CSE (Sem 1)    |    Language: Python 3    |    Library: Pygame    |    Subject: Problem Solving with Python"
    p_info.font.size = Pt(13)
    p_info.font.bold = True
    p_info.font.color.rgb = C_WHITE

    p_info2 = tfd2.add_paragraph()
    p_info2.text = "Core Concepts: Euler Physics, Game Loop Architecture, Rect Collision, State Machine, Automated Unit Testing"
    p_info2.font.size = Pt(12)
    p_info2.font.color.rgb = RGBColor(148, 163, 184)

    # Add gameplay thumbnail on the right side if exists
    if os.path.exists("assets/screenshot_gameplay.png"):
        s1.shapes.add_picture("assets/screenshot_gameplay.png", Inches(10.2), Inches(1.8), Inches(2.2), Inches(3.3))

    # =========================================================================
    # SLIDE 2: Project Overview & Objectives
    # =========================================================================
    s2 = prs.slides.add_slide(blank_layout)
    set_slide_background(s2, C_LIGHT_BG)
    add_header(s2, "Project Overview & Academic Objectives")

    # 3 Feature Cards
    card_w = Inches(3.7)
    card_h = Inches(5.3)
    top_pos = Inches(1.6)

    # Card 1: The Challenge
    add_card(s2, Inches(0.8), top_pos, card_w, card_h)
    c1_box = s2.shapes.add_textbox(Inches(1.0), top_pos + Inches(0.2), card_w - Inches(0.4), card_h - Inches(0.4))
    tf_c1 = c1_box.text_frame
    tf_c1.word_wrap = True
    p = tf_c1.paragraphs[0]
    p.text = "1. Problem Goal"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_NAVY

    items_c1 = [
        "Recreate the world-famous Flappy Bird arcade game from scratch.",
        "Strictly adhere to university specifications given in PS-45.",
        "Simulate constant downward gravitational pull on the bird entity.",
        "Implement realistic flap mechanics via user input (SPACE key).",
        "Maintain continuous 60 FPS rendering without lag or memory leaks."
    ]
    for item in items_c1:
        pi = tf_c1.add_paragraph()
        pi.text = "• " + item
        pi.font.size = Pt(13)
        pi.font.color.rgb = C_TEXT_DARK

    # Card 2: Key Concepts Applied
    add_card(s2, Inches(4.8), top_pos, card_w, card_h)
    c2_box = s2.shapes.add_textbox(Inches(5.0), top_pos + Inches(0.2), card_w - Inches(0.4), card_h - Inches(0.4))
    tf_c2 = c2_box.text_frame
    tf_c2.word_wrap = True
    p = tf_c2.paragraphs[0]
    p.text = "2. Key Concepts"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_ACCENT_BLUE

    items_c2 = [
        "Pygame Game Loop: Sequential handling of Events, Physics, Logic, Render, and Clock.",
        "Discrete Physics: Gravity acceleration (v += 1) and impulse velocity (v = -10).",
        "AABB Collision Detection: Using Pygame's Rect.colliderect() algorithm.",
        "Dynamic Procedural Generation: Randomized pipe heights with guaranteed traversable gaps.",
        "Memory Management: Dynamic pruning of off-screen game objects."
    ]
    for item in items_c2:
        pi = tf_c2.add_paragraph()
        pi.text = "• " + item
        pi.font.size = Pt(13)
        pi.font.color.rgb = C_TEXT_DARK

    # Card 3: Verification & Robustness
    add_card(s2, Inches(8.8), top_pos, card_w, card_h)
    c3_box = s2.shapes.add_textbox(Inches(9.0), top_pos + Inches(0.2), card_w - Inches(0.4), card_h - Inches(0.4))
    tf_c3 = c3_box.text_frame
    tf_c3.word_wrap = True
    p = tf_c3.paragraphs[0]
    p.text = "3. Compliance & Tests"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_GREEN

    items_c3 = [
        "Zero Hardcoded Shortcuts: Pure mathematical simulation.",
        "Automated Test Suite: Embedded runner for headless continuous integration.",
        "100% PS-45 Compliance: Exactly matches all 4 university question paper test scenarios.",
        "Edge Case Handling: Ceiling limits, ground collision, and invalid keystroke filtering.",
        "Single-File Portability: Fully self-contained inside flappy_bird.py."
    ]
    for item in items_c3:
        pi = tf_c3.add_paragraph()
        pi.text = "• " + item
        pi.font.size = Pt(13)
        pi.font.color.rgb = C_TEXT_DARK

    # =========================================================================
    # SLIDE 3: Problem Statement Specifications (PS-45)
    # =========================================================================
    s3 = prs.slides.add_slide(blank_layout)
    set_slide_background(s3, C_LIGHT_BG)
    add_header(s3, "Exact Specifications (University PS No. 45)")

    # Left: Specs Table
    table_shape = s3.shapes.add_table(7, 3, Inches(0.8), Inches(1.6), Inches(7.5), Inches(5.0))
    table = table_shape.table
    table.columns[0].width = Inches(2.2)
    table.columns[1].width = Inches(2.2)
    table.columns[2].width = Inches(3.1)

    headers = ["Parameter", "Specified Value", "Engineering Purpose"]
    for i, h in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = h
        cell.fill.solid()
        cell.fill.fore_color.rgb = C_NAVY
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(13)
        p.font.bold = True
        p.font.color.rgb = C_WHITE

    rows_data = [
        ("Window Size", "400 x 600 px", "Standard arcade portrait aspect ratio (2:3)"),
        ("Bird Dimensions", "30 x 30 px", "Hitbox size for AABB collision calculations"),
        ("Bird Starting Position", "x = 100, y = 300", "Spawns at horizontal center-left and vertical mid"),
        ("Physics (Gravity)", "velocity += 1 / frame", "Uniform downward acceleration (g = 1 px/frame²)"),
        ("Flap Impulse", "velocity = -10", "Triggered by SPACE key before frame update"),
        ("Obstacle (Pipes)", "Width: 60 px | Gap: 150 px", "Horizontal speed 3 px/frame; vertical gap 150px")
    ]

    for row_idx, r in enumerate(rows_data, start=1):
        for col_idx, text in enumerate(r):
            cell = table.cell(row_idx, col_idx)
            cell.text = text
            cell.fill.solid()
            cell.fill.fore_color.rgb = C_CARD_BG if row_idx % 2 == 0 else C_LIGHT_BG
            p = cell.text_frame.paragraphs[0]
            p.font.size = Pt(12)
            p.font.color.rgb = C_TEXT_DARK
            if col_idx == 0:
                p.font.bold = True

    # Right: Rules & Criteria Card
    add_card(s3, Inches(8.7), Inches(1.6), Inches(3.8), Inches(5.0), C_CARD_BG, C_ACCENT_BLUE)
    r_box = s3.shapes.add_textbox(Inches(8.9), Inches(1.8), Inches(3.4), Inches(4.6))
    tf_r = r_box.text_frame
    tf_r.word_wrap = True
    p = tf_r.paragraphs[0]
    p.text = "Collision & Termination Rules"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = C_ACCENT_BLUE

    rules = [
        ("Ground Collision", "Triggered when bird bottom edge >= 600 px (bird.y + 30 >= 600)."),
        ("Ceiling Limit", "Triggered when bird top edge < 0 px (bird leaves top of screen)."),
        ("Pipe Collision", "Triggered when Rect.colliderect() evaluates True for top or bottom pipe."),
        ("Score Point (+1)", "Awarded when pipe right edge (x + 60) < bird.x (100)."),
        ("Invalid Input", "Keys other than SPACE (e.g. 'Z') are strictly ignored without side effects.")
    ]
    for title, desc in rules:
        p_t = tf_r.add_paragraph()
        p_t.text = "▶ " + title
        p_t.font.size = Pt(13)
        p_t.font.bold = True
        p_t.font.color.rgb = C_NAVY

        p_d = tf_r.add_paragraph()
        p_d.text = desc
        p_d.font.size = Pt(11)
        p_d.font.color.rgb = C_TEXT_MUTED

    # =========================================================================
    # SLIDE 4: Architecture & Game Loop
    # =========================================================================
    s4 = prs.slides.add_slide(blank_layout)
    set_slide_background(s4, C_LIGHT_BG)
    add_header(s4, "System Architecture & The Pygame Game Loop")

    # 4 Flow Steps
    step_w = Inches(2.7)
    step_h = Inches(5.0)
    top_pos = Inches(1.6)

    steps = [
        ("1. Event Polling", C_ACCENT_BLUE, [
            "Reads pygame.event.get() queue",
            "QUIT event triggers clean exit",
            "SPACE key down triggers flap()",
            "Sets velocity = -10 instantaneously",
            "Any invalid key (e.g., 'Z') filtered"
        ]),
        ("2. Physics & State", C_GOLD, [
            "Gravitational acceleration added:",
            "  velocity += 1",
            "Euler position integration:",
            "  y += velocity",
            "Bird bounding box coordinates updated",
            "Pipes advance: pipe.x -= 3"
        ]),
        ("3. Collision & Score", C_RED, [
            "Check bird.rect against obstacles",
            "AABB Pipe collision test",
            "Ground limit test (bottom >= 600)",
            "Top limit test (top < 0)",
            "If pipe.right < bird.x & unpassed:",
            "  score += 1"
        ]),
        ("4. Render & Sync", C_GREEN, [
            "Clear screen & draw sky gradient",
            "Render backdrop scenery & pipes",
            "Draw bird with animated tilt/wing",
            "Draw HUD score with drop shadow",
            "pygame.display.flip() buffer swap",
            "clock.tick(60) locks frame rate"
        ])
    ]

    for idx, (stitle, scolor, sbullets) in enumerate(steps):
        left_pos = Inches(0.8 + idx * 2.95)
        add_card(s4, left_pos, top_pos, step_w, step_h)
        
        # Header inside card
        hdr_shape = s4.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left_pos, top_pos, step_w, Inches(0.7))
        hdr_shape.fill.solid()
        hdr_shape.fill.fore_color.rgb = scolor
        hdr_shape.line.fill.background()
        
        tf_h = hdr_shape.text_frame
        p = tf_h.paragraphs[0]
        p.text = stitle
        p.font.size = Pt(14)
        p.font.bold = True
        p.font.color.rgb = C_WHITE
        p.alignment = PP_ALIGN.CENTER

        # Bullets
        txt_box = s4.shapes.add_textbox(left_pos + Inches(0.15), top_pos + Inches(0.8), step_w - Inches(0.3), step_h - Inches(0.9))
        tf_b = txt_box.text_frame
        tf_b.word_wrap = True
        for b_idx, bullet in enumerate(sbullets):
            p_b = tf_b.paragraphs[0] if b_idx == 0 else tf_b.add_paragraph()
            p_b.text = bullet
            p_b.font.size = Pt(12)
            p_b.font.color.rgb = C_TEXT_DARK

    # =========================================================================
    # SLIDE 5: Physics & Mathematical Formulation
    # =========================================================================
    s5 = prs.slides.add_slide(blank_layout)
    set_slide_background(s5, C_LIGHT_BG)
    add_header(s5, "Physics Engine: Discrete Euler Integration")

    # Card Left: Equations
    add_card(s5, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.1))
    eq_box = s5.shapes.add_textbox(Inches(1.1), Inches(1.8), Inches(5.0), Inches(4.7))
    tf_eq = eq_box.text_frame
    tf_eq.word_wrap = True

    p = tf_eq.paragraphs[0]
    p.text = "Mathematical Formulation"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_NAVY

    eqs = [
        ("Uniform Gravity Acceleration:", "v[t+1] = v[t] + g   (where g = 1 px/frame²)"),
        ("Position Integration (Euler):", "y[t+1] = y[t] + v[t+1]"),
        ("Impulse Jump (SPACE pressed):", "v[t] = -10 px/frame (before integration)"),
        ("Terminal Downward Motion:", "No clamp required; parabolic descent occurs naturally.")
    ]
    for title, formula in eqs:
        pt = tf_eq.add_paragraph()
        pt.text = title
        pt.font.size = Pt(13)
        pt.font.bold = True
        pt.font.color.rgb = C_ACCENT_BLUE

        pf = tf_eq.add_paragraph()
        pf.text = formula
        pf.font.size = Pt(12)
        pf.font.color.rgb = C_TEXT_DARK

    # Card Right: Numerical Step-by-Step Simulation Table
    add_card(s5, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.1))
    sim_box = s5.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.7))
    tf_sim = sim_box.text_frame
    tf_sim.word_wrap = True

    p = tf_sim.paragraphs[0]
    p.text = "Sample Physics Simulation Trace"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_GREEN

    traces = [
        "Scenario A: Free Fall from Rest (y = 300, v = 0)",
        "• Initial State: y = 300, v = 0",
        "• Frame 1: v = 0 + 1 = 1  ==>  y = 300 + 1 = 301",
        "• Frame 2: v = 1 + 1 = 2  ==>  y = 301 + 2 = 303",
        "• Frame 3: v = 2 + 1 = 3  ==>  y = 303 + 3 = 306",
        "",
        "Scenario B: Flap Applied mid-flight (y = 300, v = 5)",
        "• Player presses SPACE: v is reset to -10",
        "• Frame update: v = -10 + 1 = -9",
        "• New Position: y = 300 + (-9) = 291  (Moves 9px upward!)",
        "• Frame 2: v = -9 + 1 = -8 ==> y = 291 + (-8) = 283"
    ]
    for trace in traces:
        pt = tf_sim.add_paragraph()
        pt.text = trace
        pt.font.size = Pt(12)
        pt.font.color.rgb = C_NAVY if "Scenario" in trace else C_TEXT_DARK
        if "Scenario" in trace:
            pt.font.bold = True

    # =========================================================================
    # SLIDE 6: Collision Detection Engine (AABB)
    # =========================================================================
    s6 = prs.slides.add_slide(blank_layout)
    set_slide_background(s6, C_LIGHT_BG)
    add_header(s6, "Collision Detection Mechanism: Axis-Aligned Bounding Box")

    # 3 horizontal breakdown cards
    col_w = Inches(3.7)
    col_h = Inches(5.1)

    # 1. Pipe Collision
    add_card(s6, Inches(0.8), Inches(1.6), col_w, col_h)
    box1 = s6.shapes.add_textbox(Inches(1.0), Inches(1.8), col_w - Inches(0.4), col_h - Inches(0.4))
    tf1 = box1.text_frame
    tf1.word_wrap = True
    p = tf1.paragraphs[0]
    p.text = "1. Pipe Collision"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_RED

    p_body1 = [
        "Uses Pygame Rect.colliderect() method.",
        "Both pipes (Top & Bottom) tested separately against bird rectangle.",
        "Mathematical Condition for overlap:",
        "  Bird.Right > Pipe.Left AND",
        "  Bird.Left < Pipe.Right AND",
        "  Bird.Bottom > Pipe.Top AND",
        "  Bird.Top < Pipe.Bottom",
        "Instantly triggers Game Over state."
    ]
    for b in p_body1:
        pb = tf1.add_paragraph()
        pb.text = "• " + b
        pb.font.size = Pt(12)
        pb.font.color.rgb = C_TEXT_DARK

    # 2. Ground Collision
    add_card(s6, Inches(4.8), Inches(1.6), col_w, col_h)
    box2 = s6.shapes.add_textbox(Inches(5.0), Inches(1.8), col_w - Inches(0.4), col_h - Inches(0.4))
    tf2 = box2.text_frame
    tf2.word_wrap = True
    p = tf2.paragraphs[0]
    p.text = "2. Ground Collision"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_GOLD

    p_body2 = [
        "Ground line is situated at y = 600.",
        "Bird bottom edge is calculated as:",
        "  bird_rect.bottom = bird.y + 30",
        "Condition: bird_rect.bottom >= 600",
        "Boundary test (TC-2a):",
        "  When bird.y = 570:",
        "  bottom = 570 + 30 = 600",
        "  Immediately triggers Game Over!"
    ]
    for b in p_body2:
        pb = tf2.add_paragraph()
        pb.text = "• " + b
        pb.font.size = Pt(12)
        pb.font.color.rgb = C_TEXT_DARK

    # 3. Ceiling Exit
    add_card(s6, Inches(8.8), Inches(1.6), col_w, col_h)
    box3 = s6.shapes.add_textbox(Inches(9.0), Inches(1.8), col_w - Inches(0.4), col_h - Inches(0.4))
    tf3 = box3.text_frame
    tf3.word_wrap = True
    p = tf3.paragraphs[0]
    p.text = "3. Ceiling Exit Limit"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_NAVY

    p_body3 = [
        "Prevents the bird from flying off the top of the playable window.",
        "Condition: bird_rect.top < 0",
        "Boundary test (TC-2b):",
        "  Bird at y = 5, velocity = 0",
        "  SPACE pressed -> v = -10",
        "  Frame update: v = -9, y = -4",
        "  top = -4 < 0  ==>  Out of screen!",
        "Game terminates with Top Exit flag."
    ]
    for b in p_body3:
        pb = tf3.add_paragraph()
        pb.text = "• " + b
        pb.font.size = Pt(12)
        pb.font.color.rgb = C_TEXT_DARK

    # =========================================================================
    # SLIDE 7: Pipe Generation & Scoring Logic
    # =========================================================================
    s7 = prs.slides.add_slide(blank_layout)
    set_slide_background(s7, C_LIGHT_BG)
    add_header(s7, "Procedural Generation & Edge-Crossing Score Logic")

    # Left card: Generation & Gap Math
    add_card(s7, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.1))
    gen_box = s7.shapes.add_textbox(Inches(1.1), Inches(1.8), Inches(5.0), Inches(4.7))
    tf_g = gen_box.text_frame
    tf_g.word_wrap = True

    p = tf_g.paragraphs[0]
    p.text = "Obstacle Geometry & Gap Logic"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_NAVY

    gen_points = [
        "Spawn Timing: Exactly every 90 frames (~1.5 seconds at 60 FPS).",
        "Pipe Dimensions: Width = 60 px, Vertical Clearance Gap = 150 px.",
        "Traversability Guarantee:",
        "  min_gap_y = 50 px (ensures top pipe is always visible)",
        "  max_gap_y = 600 - 150 - 50 = 400 px (bottom pipe visibility)",
        "  gap_y is uniformly sampled: random.randint(50, 400)",
        "Dynamic Cleanup:",
        "  Pipes with x + width < 0 are pruned to prevent memory accumulation."
    ]
    for pt in gen_points:
        p_pt = tf_g.add_paragraph()
        p_pt.text = "• " + pt
        p_pt.font.size = Pt(12)
        p_pt.font.color.rgb = C_TEXT_DARK

    # Right card: Scoring Logic
    add_card(s7, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.1))
    sc_box = s7.shapes.add_textbox(Inches(7.1), Inches(1.8), Inches(5.1), Inches(4.7))
    tf_s = sc_box.text_frame
    tf_s.word_wrap = True

    p = tf_s.paragraphs[0]
    p.text = "Score Trigger Mechanism"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_GREEN

    score_points = [
        "Score increases by +1 when bird successfully navigates through pipe.",
        "Mathematical Trigger Condition:",
        "  not pipe.passed AND (pipe.x + pipe.width) < bird.x",
        "  ==>  pipe.x + 60 < 100  ==>  pipe.x < 40",
        "Flag Lock (pipe.passed = True):",
        "  Guarantees each pipe awards exactly 1 point once.",
        "TC-4(b) University Verification:",
        "  Pipe placed at x = 39, width = 60",
        "  Pipe right edge = 39 + 60 = 99 px < Bird x (100 px)",
        "  Output confirmed: Pipe passed | Score: 1"
    ]
    for pt in score_points:
        p_pt = tf_s.add_paragraph()
        p_pt.text = "• " + pt
        p_pt.font.size = Pt(12)
        p_pt.font.color.rgb = C_TEXT_DARK

    # =========================================================================
    # SLIDE 8: University Test Cases Verification Table (Core slide!)
    # =========================================================================
    s8 = prs.slides.add_slide(blank_layout)
    set_slide_background(s8, C_LIGHT_BG)
    add_header(s8, "Verification & Automated University Test Suite (PS-45)")

    # Test cases table
    tc_table_shape = s8.shapes.add_table(6, 6, Inches(0.8), Inches(1.6), Inches(11.7), Inches(4.5))
    tc_table = tc_table_shape.table
    tc_table.columns[0].width = Inches(1.1)  # Case
    tc_table.columns[1].width = Inches(2.2)  # Scenario
    tc_table.columns[2].width = Inches(2.6)  # Inputs
    tc_table.columns[3].width = Inches(2.4)  # Expected
    tc_table.columns[4].width = Inches(2.4)  # Actual
    tc_table.columns[5].width = Inches(1.0)  # Status

    tc_headers = ["Test", "Scenario Type", "Input Conditions", "Expected Output", "Actual Output", "Status"]
    for i, h in enumerate(tc_headers):
        cell = tc_table.cell(0, i)
        cell.text = h
        cell.fill.solid()
        cell.fill.fore_color.rgb = C_NAVY
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(12)
        p.font.bold = True
        p.font.color.rgb = C_WHITE
        p.alignment = PP_ALIGN.CENTER

    test_data = [
        ("TC-1", "Normal Input (Gravity)", "y=300, v=0, No key, 2 frames", "F1: v=1, y=301\nF2: v=2, y=303", "F1: v=1, y=301\nF2: v=2, y=303", "PASSED"),
        ("TC-2a", "Boundary (Ground Hit)", "y=570, v=0, bird bottom touches 600", "Collision with ground | Game Over", "Collision with ground | Game Over", "PASSED"),
        ("TC-2b", "Boundary (Top Exit)", "y=5, v=0, SPACE pressed, 1 frame", "v=-9, y=-4 | Bird left screen at top | Game Over", "v=-9, y=-4 | Bird left screen at top | Game Over", "PASSED"),
        ("TC-3", "Invalid Keystroke", "y=300, v=0, Press 'Z' key, 1 frame", "Key ignored | v=1, y=301", "Key ignored | v=1, y=301", "PASSED"),
        ("TC-4", "Flap & Score Logic", "(a) y=300, v=5, SPACE -> 1 frame\n(b) Pipe x=39, bird x=100", "(a) v=-9, y=291 (moves up)\n(b) Pipe passed | Score: 1", "(a) v=-9, y=291 (moves up)\n(b) Pipe passed | Score: 1", "PASSED")
    ]

    for row_idx, row in enumerate(test_data, start=1):
        for col_idx, val in enumerate(row):
            cell = tc_table.cell(row_idx, col_idx)
            cell.text = val
            cell.fill.solid()
            cell.fill.fore_color.rgb = C_CARD_BG if row_idx % 2 == 0 else RGBColor(241, 245, 249)
            p = cell.text_frame.paragraphs[0]
            p.font.size = Pt(11)
            p.font.color.rgb = C_TEXT_DARK
            if col_idx == 0:
                p.font.bold = True
                p.alignment = PP_ALIGN.CENTER
            elif col_idx == 5:
                p.font.bold = True
                p.font.color.rgb = C_DARK_GREEN
                p.alignment = PP_ALIGN.CENTER

    # Verification banner at bottom
    v_card = add_card(s8, Inches(0.8), Inches(6.3), Inches(11.7), Inches(0.7), RGBColor(236, 253, 245), C_GREEN)
    v_box = s8.shapes.add_textbox(Inches(1.0), Inches(6.35), Inches(11.3), Inches(0.6))
    tf_v = v_box.text_frame
    pv = tf_v.paragraphs[0]
    pv.text = "✓ 100% SUCCESS: All 4 test cases executed and strictly validated via automated test runner: `python flappy_bird.py --test`"
    pv.font.size = Pt(13)
    pv.font.bold = True
    pv.font.color.rgb = C_DARK_GREEN

    # =========================================================================
    # SLIDE 9: Visual Gameplay & UI Architecture
    # =========================================================================
    s9 = prs.slides.add_slide(blank_layout)
    set_slide_background(s9, C_LIGHT_BG)
    add_header(s9, "Graphical User Interface & Visual Assets")

    # Embed Screenshots side by side
    img_w = Inches(3.2)
    img_h = Inches(4.8)
    
    if os.path.exists("assets/screenshot_gameplay.png"):
        s9.shapes.add_picture("assets/screenshot_gameplay.png", Inches(0.8), Inches(1.7), img_w, img_h)
        caption1 = s9.shapes.add_textbox(Inches(0.8), Inches(6.6), img_w, Inches(0.5))
        caption1.text_frame.paragraphs[0].text = "Active Gameplay View (HUD & Score)"
        caption1.text_frame.paragraphs[0].font.size = Pt(11)
        caption1.text_frame.paragraphs[0].font.bold = True
        caption1.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

    if os.path.exists("assets/screenshot_gameover.png"):
        s9.shapes.add_picture("assets/screenshot_gameover.png", Inches(4.4), Inches(1.7), img_w, img_h)
        caption2 = s9.shapes.add_textbox(Inches(4.4), Inches(6.6), img_w, Inches(0.5))
        caption2.text_frame.paragraphs[0].text = "Game Over Modal & Restart Option"
        caption2.text_frame.paragraphs[0].font.size = Pt(11)
        caption2.text_frame.paragraphs[0].font.bold = True
        caption2.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

    # Right side: Visual Design Highlights Card
    add_card(s9, Inches(8.0), Inches(1.7), Inches(4.5), Inches(4.8))
    ui_box = s9.shapes.add_textbox(Inches(8.2), Inches(1.9), Inches(4.1), Inches(4.4))
    tf_ui = ui_box.text_frame
    tf_ui.word_wrap = True

    p = tf_ui.paragraphs[0]
    p.text = "Visual & UX Enhancements"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_NAVY

    ui_highlights = [
        "Retro Pixel-Art Bird: Custom 30x30 procedural sprite featuring yellow body, orange beak, expressive eye, and dynamic flapping wing.",
        "Gradient Sky & Backdrop: Atmospheric sky gradient with layered clouds and distant skyline silhouette.",
        "3D Stylized Pipes: Green classic pipes with light highlights, dark bevel shadows, and rim caps.",
        "Typography & HUD: High-contrast typography with drop shadows for crystal-clear readability.",
        "Interactive Game Over Overlay: Semi-transparent modal displaying final score and restart prompt (SPACE key)."
    ]
    for h in ui_highlights:
        ph = tf_ui.add_paragraph()
        ph.text = "▶ " + h
        ph.font.size = Pt(11)
        ph.font.color.rgb = C_TEXT_DARK

    # =========================================================================
    # SLIDE 10: OOP Design & Code Structure
    # =========================================================================
    s10 = prs.slides.add_slide(blank_layout)
    set_slide_background(s10, C_LIGHT_BG)
    add_header(s10, "Code Architecture & Object-Oriented Design")

    # 3 Class Cards
    card_w = Inches(3.7)
    card_h = Inches(5.1)

    # Class 1: Bird
    add_card(s10, Inches(0.8), Inches(1.6), card_w, card_h)
    b_box = s10.shapes.add_textbox(Inches(1.0), Inches(1.8), card_w - Inches(0.4), card_h - Inches(0.4))
    tf_b = b_box.text_frame
    tf_b.word_wrap = True
    p = tf_b.paragraphs[0]
    p.text = "class Bird"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_GOLD

    bird_oop = [
        "Encapsulates bird state & physics.",
        "Attributes:",
        "  self.x, self.y (100, 300)",
        "  self.velocity (0)",
        "  self.rect (pygame.Rect 30x30)",
        "Key Methods:",
        "  flap(): Sets velocity = -10",
        "  update_physics(): v += 1, y += v",
        "  reset(): Restores initial state",
        "  draw(surface): Procedural rendering"
    ]
    for item in bird_oop:
        pi = tf_b.add_paragraph()
        pi.text = item
        pi.font.size = Pt(12)
        pi.font.color.rgb = C_TEXT_DARK

    # Class 2: Pipe
    add_card(s10, Inches(4.8), Inches(1.6), card_w, card_h)
    p_box = s10.shapes.add_textbox(Inches(5.0), Inches(1.8), card_w - Inches(0.4), card_h - Inches(0.4))
    tf_p = p_box.text_frame
    tf_p.word_wrap = True
    p = tf_p.paragraphs[0]
    p.text = "class Pipe"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_GREEN

    pipe_oop = [
        "Represents dual obstacle column.",
        "Attributes:",
        "  self.x, self.gap_y",
        "  self.top_rect, self.bot_rect",
        "  self.passed (boolean score flag)",
        "Key Methods:",
        "  update(): Shifts x by -3 px",
        "  update_rects(): Synchronizes Rects",
        "  collides_with(bird_rect): Returns bool",
        "  draw(surface): Renders body & rims"
    ]
    for item in pipe_oop:
        pi = tf_p.add_paragraph()
        pi.text = item
        pi.font.size = Pt(12)
        pi.font.color.rgb = C_TEXT_DARK

    # Class 3: FlappyBirdGame
    add_card(s10, Inches(8.8), Inches(1.6), card_w, card_h)
    g_box = s10.shapes.add_textbox(Inches(9.0), Inches(1.8), card_w - Inches(0.4), card_h - Inches(0.4))
    tf_g = g_box.text_frame
    tf_g.word_wrap = True
    p = tf_g.paragraphs[0]
    p.text = "class FlappyBirdGame"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_NAVY

    game_oop = [
        "Central game orchestrator.",
        "Attributes:",
        "  self.bird, self.pipes, self.score",
        "  self.game_over, self.headless",
        "Key Methods:",
        "  run(): 60 FPS master loop",
        "  handle_input(key): Keystroke filter",
        "  update_frame(): Single frame tick",
        "  check_collisions(): Tri-boundary test",
        "  draw(): Canvas rendering & flip"
    ]
    for item in game_oop:
        pi = tf_g.add_paragraph()
        pi.text = item
        pi.font.size = Pt(12)
        pi.font.color.rgb = C_TEXT_DARK

    # =========================================================================
    # SLIDE 11: Key Learnings & Future Enhancements
    # =========================================================================
    s11 = prs.slides.add_slide(blank_layout)
    set_slide_background(s11, C_LIGHT_BG)
    add_header(s11, "Academic Learnings & Future Enhancements")

    # Left: Learnings
    add_card(s11, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.1))
    l_box = s11.shapes.add_textbox(Inches(1.1), Inches(1.8), Inches(5.0), Inches(4.7))
    tf_l = l_box.text_frame
    tf_l.word_wrap = True
    p = tf_l.paragraphs[0]
    p.text = "Key Academic Learnings"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_NAVY

    learnings = [
        ("Discrete 2D Physics Modeling", "Gained practical experience translating theoretical kinematics (acceleration, impulse, velocity) into computational algorithms."),
        ("AABB Collision Algorithms", "Understood spatial bounding box collision mathematics and boundary handling in real-time graphic systems."),
        ("Event-Driven Architecture", "Mastered Pygame event queues, continuous frame loops, and non-blocking state transitions."),
        ("Test-Driven Verification (TDD)", "Implemented automated headless test assertions to rigorously validate edge cases before delivery.")
    ]
    for title, desc in learnings:
        pt = tf_l.add_paragraph()
        pt.text = "✓ " + title
        pt.font.size = Pt(13)
        pt.font.bold = True
        pt.font.color.rgb = C_ACCENT_BLUE

        pd = tf_l.add_paragraph()
        pd.text = desc
        pd.font.size = Pt(11)
        pd.font.color.rgb = C_TEXT_MUTED

    # Right: Future Scope
    add_card(s11, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.1))
    f_box = s11.shapes.add_textbox(Inches(7.1), Inches(1.8), Inches(5.1), Inches(4.7))
    tf_f = f_box.text_frame
    tf_f.word_wrap = True
    p = tf_f.paragraphs[0]
    p.text = "Future Scope & Enhancements"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = C_GREEN

    futures = [
        ("Synthesized Audio Engine", "Incorporate sound synthesizers (numpy/pygame.mixer) for flap, score ding, and collision impact SFX."),
        ("Dynamic Difficulty Scaling", "Gradually increase pipe speed or reduce vertical gap spacing as the score increases."),
        ("Persistent Leaderboard", "Integrate file I/O or SQLite database to track and save local and global high scores."),
        ("AI Agent Integration (NEAT)", "Train an autonomous neural network using Genetic Algorithms to master playing Flappy Bird.")
    ]
    for title, desc in futures:
        pt = tf_f.add_paragraph()
        pt.text = "★ " + title
        pt.font.size = Pt(13)
        pt.font.bold = True
        pt.font.color.rgb = C_DARK_GREEN

        pd = tf_f.add_paragraph()
        pd.text = desc
        pd.font.size = Pt(11)
        pd.font.color.rgb = C_TEXT_MUTED

    # =========================================================================
    # SLIDE 12: Conclusion & Q&A Slide (Dark Theme)
    # =========================================================================
    s12 = prs.slides.add_slide(blank_layout)
    set_slide_background(s12, C_NAVY)

    # Decorative frame
    add_card(s12, Inches(1.5), Inches(1.2), Inches(10.333), Inches(5.1), C_DARK_BLUE, C_ACCENT_BLUE)

    qa_box = s12.shapes.add_textbox(Inches(1.8), Inches(1.5), Inches(9.7), Inches(4.5))
    tf_qa = qa_box.text_frame
    tf_qa.word_wrap = True

    p = tf_qa.paragraphs[0]
    p.text = "THANK YOU!"
    p.font.size = Pt(40)
    p.font.bold = True
    p.font.color.rgb = C_GOLD
    p.alignment = PP_ALIGN.CENTER

    p_sub = tf_qa.add_paragraph()
    p_sub.text = "Questions & Feedback are Welcome"
    p_sub.font.size = Pt(20)
    p_sub.font.color.rgb = C_WHITE
    p_sub.alignment = PP_ALIGN.CENTER

    p_div = tf_qa.add_paragraph()
    p_div.text = "—" * 30
    p_div.font.size = Pt(14)
    p_div.font.color.rgb = C_ACCENT_BLUE
    p_div.alignment = PP_ALIGN.CENTER

    summary_pts = [
        "Project: Flappy Bird Clone (Problem Statement No. 45)",
        "Institution: Rungta International Skills University",
        "Department: School of Computer Science and Engineering",
        "Compliance: 100% Validated against all 4 University Specifications",
        "Interactive Demo: Ready to demonstrate live!"
    ]
    for pt in summary_pts:
        p_pt = tf_qa.add_paragraph()
        p_pt.text = pt
        p_pt.font.size = Pt(14)
        p_pt.font.color.rgb = RGBColor(226, 232, 240)
        p_pt.alignment = PP_ALIGN.CENTER

    # Save presentation
    output_path = "Flappy_Bird_Presentation_PS45.pptx"
    prs.save(output_path)
    print(f"Presentation successfully created and saved to: {output_path}")

if __name__ == "__main__":
    create_deck()
