import os
import wave
import math
import struct
import random

SOUNDS_DIR = os.path.join(os.path.dirname(__file__), "assets", "sounds")

def write_wav(filepath, samples, sample_rate=44100):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with wave.open(filepath, "w") as wav_file:
        wav_file.setnchannels(1)        # Mono
        wav_file.setsampwidth(2)       # 16-bit
        wav_file.setframerate(sample_rate)
        raw_data = b"".join(
            struct.pack("<h", max(-32768, min(32767, int(s * 32767))))
            for s in samples
        )
        wav_file.writeframes(raw_data)

def generate_all_sounds():
    """Generates all standalone 8-bit / arcade sound effects for Flappy Bird."""
    os.makedirs(SOUNDS_DIR, exist_ok=True)
    rate = 44100

    # 1. Flap / Wing whoosh sound
    flap_path = os.path.join(SOUNDS_DIR, "flap.wav")
    if not os.path.exists(flap_path):
        dur = 0.12
        samples = []
        for i in range(int(rate * dur)):
            t = i / rate
            progress = t / dur
            freq = 350 + 650 * progress
            env = math.sin(math.pi * progress)
            # Soft chirp + harmonic
            val = (0.75 * math.sin(2 * math.pi * freq * t) + 
                   0.25 * math.sin(4 * math.pi * freq * t)) * env
            samples.append(val * 0.7)
        write_wav(flap_path, samples, rate)

    # 2. Point / Score chime (crisp double bell chime)
    point_path = os.path.join(SOUNDS_DIR, "point.wav")
    if not os.path.exists(point_path):
        dur = 0.28
        samples = []
        for i in range(int(rate * dur)):
            t = i / rate
            freq = 988 if t < 0.10 else 1319  # B5 then E6
            local_t = t if t < 0.10 else (t - 0.10)
            env = math.exp(-local_t * 12)
            val = (math.sin(2 * math.pi * freq * t) + 
                   0.3 * math.sin(4 * math.pi * freq * t)) * env
            samples.append(val * 0.65)
        write_wav(point_path, samples, rate)

    # 3. Hit / Collision smack sound
    hit_path = os.path.join(SOUNDS_DIR, "hit.wav")
    if not os.path.exists(hit_path):
        dur = 0.22
        samples = []
        for i in range(int(rate * dur)):
            t = i / rate
            env = math.exp(-t * 22)
            noise = (random.random() * 2 - 1) * 0.65
            low_thump = math.sin(2 * math.pi * (140 * (1 - t / dur)) * t) * 0.45
            samples.append((noise + low_thump) * env)
        write_wav(hit_path, samples, rate)

    # 4. Die / Falling whimper sound
    die_path = os.path.join(SOUNDS_DIR, "die.wav")
    if not os.path.exists(die_path):
        dur = 0.38
        samples = []
        for i in range(int(rate * dur)):
            t = i / rate
            progress = t / dur
            freq = max(55.0, 520.0 * ((1.0 - progress) ** 1.8))
            env = math.exp(-t * 3.5)
            val = math.sin(2 * math.pi * freq * t) * env
            samples.append(val * 0.75)
        write_wav(die_path, samples, rate)

    # 5. Swoosh / Menu transition sound
    swoosh_path = os.path.join(SOUNDS_DIR, "swoosh.wav")
    if not os.path.exists(swoosh_path):
        dur = 0.16
        samples = []
        for i in range(int(rate * dur)):
            t = i / rate
            progress = t / dur
            freq = 320 + 260 * math.sin(math.pi * progress)
            env = math.sin(math.pi * progress)
            val = (math.sin(2 * math.pi * freq * t) * 0.6 + (random.random() - 0.5) * 0.2) * env
            samples.append(val * 0.55)
        write_wav(swoosh_path, samples, rate)

    # 6. High Score Celebration Fanfare
    celebrate_path = os.path.join(SOUNDS_DIR, "celebrate.wav")
    if not os.path.exists(celebrate_path):
        dur = 0.5
        notes = [(0.0, 0.12, 523.25), (0.12, 0.24, 659.25), (0.24, 0.5, 783.99)] # C5, E5, G5
        samples = []
        for i in range(int(rate * dur)):
            t = i / rate
            val = 0.0
            for start, end, f in notes:
                if start <= t < end:
                    lt = t - start
                    env = math.exp(-lt * 6)
                    val = math.sin(2 * math.pi * f * t) * env
                    break
            samples.append(val * 0.6)
        write_wav(celebrate_path, samples, rate)

if __name__ == "__main__":
    generate_all_sounds()
    print("All sounds generated.")
