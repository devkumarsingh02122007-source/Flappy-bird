"""
Game constants and settings for Flappy Bird Clone.
"""

# Screen Dimensions
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600
GROUND_HEIGHT = 110

# Frame Rate
FPS = 60

# Bird Physics
GRAVITY = 0.38
FLAP_STRENGTH = -7.2
MAX_FALL_SPEED = 9.5
ROTATION_SPEED = 3.5

# Pipe Settings
PIPE_SPEED = 3.0
PIPE_GAP = 140
PIPE_WIDTH = 68
PIPE_MIN_HEIGHT = 80
PIPE_SPAWN_INTERVAL = 1450  # milliseconds

# Themes
THEMES = ["day", "sunset", "night"]

# Bird Skins
SKIN_NAMES = ["classic", "phoenix", "cyber", "neon"]

SKIN_COLORS = {
    "classic": {
        "name": "Classic Gold",
        "body": (245, 200, 35),
        "belly": (255, 235, 130),
        "wing": (230, 160, 20),
        "outline": (60, 40, 15),
        "beak": (240, 100, 25),
        "beak_highlight": (255, 160, 60),
        "cheek": (250, 140, 100, 150)
    },
    "phoenix": {
        "name": "Fire Phoenix",
        "body": (235, 60, 40),
        "belly": (255, 140, 60),
        "wing": (180, 30, 20),
        "outline": (60, 15, 10),
        "beak": (255, 215, 0),
        "beak_highlight": (255, 240, 120),
        "cheek": (255, 90, 70, 160)
    },
    "cyber": {
        "name": "Cyber Cyan",
        "body": (0, 200, 230),
        "belly": (160, 245, 255),
        "wing": (0, 140, 180),
        "outline": (10, 40, 60),
        "beak": (255, 70, 160),
        "beak_highlight": (255, 140, 200),
        "cheek": (0, 240, 255, 160)
    },
    "neon": {
        "name": "Neon Violet",
        "body": (175, 70, 240),
        "belly": (225, 170, 255),
        "wing": (120, 35, 180),
        "outline": (40, 15, 60),
        "beak": (0, 230, 180),
        "beak_highlight": (120, 255, 220),
        "cheek": (240, 100, 255, 160)
    }
}

# Medals
MEDAL_THRESHOLDS = {
    "platinum": 40,
    "gold": 30,
    "silver": 20,
    "bronze": 10
}
