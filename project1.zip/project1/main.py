"""
RUNGTA INTERNATIONAL SKILLS UNIVERSITY
SCHOOL OF COMPUTER SCIENCE AND ENGINEERING
B.Tech CSE First Semester - PS No. 45: Flappy Bird Clone

Main entry point.
Usage:
    python main.py          -> Launches the game
    python main.py --test   -> Runs the 4 assignment test cases
"""

import sys

def main():
    if len(sys.argv) > 1 and sys.argv[1] in ["--test", "-t", "test"]:
        from flappy_bird import run_all_test_cases
        run_all_test_cases()
    else:
        from flappy_bird import FlappyBirdGame
        game = FlappyBirdGame()
        game.run()

if __name__ == "__main__":
    main()
